emu2413
=======

A YM2413 emulator written in C.

