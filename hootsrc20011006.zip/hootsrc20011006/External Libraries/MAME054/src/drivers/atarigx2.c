/***************************************************************************

	Atari GX2 hardware

	driver by Aaron Giles

	Games supported:
		* Space Lords (1992) [2 sets]
		* Moto Frenzy (1992)
		* Road Riot's Revenge Rally (1993)

	Known bugs:
		* protection devices unknown

****************************************************************************

	Memory map (TBA)

***************************************************************************/


#include "driver.h"
#include "machine/atarigen.h"
#include "sndhrdw/atarijsa.h"



/*************************************
 *
 *	Externals
 *
 *************************************/

int atarig42_vh_start(void);
void atarig42_vh_stop(void);
void atarig42_vh_screenrefresh(struct osd_bitmap *bitmap, int full_refresh);

void atarigx2_scanline_update(int param);

extern UINT8 atarig42_guardian;



/*************************************
 *
 *	Statics
 *
 *************************************/

static UINT8 		which_input;
static data32_t *	protection_base;



/*************************************
 *
 *	Initialization
 *
 *************************************/

static void update_interrupts(void)
{
	int newstate = 0;

	if (atarigen_video_int_state)
		newstate = 4;
	if (atarigen_sound_int_state)
		newstate = 5;

	if (newstate)
		cpu_set_irq_line(0, newstate, ASSERT_LINE);
	else
		cpu_set_irq_line(0, 7, CLEAR_LINE);
}


static void init_machine(void)
{
	atarigen_eeprom_reset();
	atarigen_interrupt_reset(update_interrupts);
	atarigen_scanline_timer_reset(atarigx2_scanline_update, 8);
	atarijsa_reset();
}



/*************************************
 *
 *	I/O read dispatch.
 *
 *************************************/

static READ32_HANDLER( special_port2_r )
{
	int temp = readinputport(2);
	if (atarigen_cpu_to_sound_ready) temp ^= 0x0020;
	if (atarigen_sound_to_cpu_ready) temp ^= 0x0010;
	temp ^= 0x0008;		/* A2D.EOC always high for now */
	return (temp << 16) | temp;
}


static READ32_HANDLER( special_port3_r )
{
	int temp = readinputport(3);
	return (temp << 16) | temp;
}


static WRITE32_HANDLER( a2d_select_w )
{
	if (ACCESSING_MSW32)
		which_input = offset * 2;
	if (ACCESSING_LSW32)
		which_input = offset * 2 + 1;
}


static READ32_HANDLER( a2d_data_r )
{
	offset = (offset - 2) / 2;

	/* otherwise, assume it's hydra */
	switch (which_input)
	{
		case 0:
			return (readinputport(5) << 24) | (readinputport(6) << 8);
		case 1:
			return (readinputport(7) << 24) | (readinputport(8) << 8);
	}

	return 0;
}


static WRITE32_HANDLER( latch_w )
{
	/*
		D13 = 68.DISA
		D12 = ERASE
		D11 = /MOGO
		D8  = VCR
		D5  = /XRESET
		D4  = /SNDRES
		D3  = CC.L
		D0  = CC.R
	*/
	if (ACCESSING_MSW32 && !ACCESSING_MSB32)
		cpu_set_reset_line(1, (data & 0x100000) ? CLEAR_LINE : ASSERT_LINE);
}



/*************************************
 *
 *	Protection?
 *
 *************************************/

static data16_t last_write;
static data16_t last_write_offset;

static WRITE32_HANDLER( atarigx2_protection_w )
{
	{
//		int pc = cpu_getpreviouspc();
//		if (pc == 0x11cbe || pc == 0x11c30)
//			logerror("%06X:Protection W@%04X = %04X  (result to %06X)\n", pc, offset, data, cpu_get_reg(M68K_A2));
//		else
//			logerror("%06X:Protection W@%04X = %04X\n", pc, offset, data);
	}

	COMBINE_DATA(&protection_base[offset]);

	if (ACCESSING_MSW32)
	{
		last_write = protection_base[offset] >> 16;
		last_write_offset = offset*2;
	}
	if (ACCESSING_LSW32)
	{
		last_write = protection_base[offset] & 0xffff;
		last_write_offset = offset*2+1;
	}
}

static READ32_HANDLER( atarigx2_protection_r )
{
	static const UINT32 lookup_table[][2] =
	{
		// initialization

		{ 0x00000241, 0x0000 },
		{ 0x0002F1CC, 0x0000 },
		{ 0x00043996, 0x7707 },
		{ 0x0006451F, 0x3096 },
		{ 0x0008BA02, 0xee0e },
		{ 0x000A78F4, 0x612c },
		{ 0x000CB890, 0x9909 },
		{ 0x000EF8A2, 0x51ba },
		{ 0x00105C79, 0x076d },
		{ 0x00121D13, 0xc419 },
		{ 0x00148CB8, 0x706a },
		{ 0x00162C65, 0xf48f },
		{ 0x0018FABB, 0xe963 },
		{ 0x001A2A33, 0xa535 },
		{ 0x001CF0DD, 0x9e64 },
		{ 0x001E8C14, 0x95a3 },
		{ 0x0020F239, 0x0edb },
		{ 0x00228E87, 0x8832 },
		{ 0x0024B022, 0x79dc },
		{ 0x00261D55, 0xb8a4 },
		{ 0x002889AB, 0xe0d5 },
		{ 0x002A935B, 0xe91e },
		{ 0x002C7BAE, 0x97d2 },
		{ 0x002E39D1, 0xd988 },
		{ 0x0030E44E, 0x09b6 },
		{ 0x00321765, 0x4c2b },
		{ 0x003487FF, 0x7eb1 },
		{ 0x003658C2, 0x7cbd },
		{ 0x00381E83, 0xe7b8 },
		{ 0x003A77CD, 0x2d07 },
		{ 0x003CCAE4, 0x90bf },
		{ 0x003EC0CB, 0x1d91 },
		{ 0x00409494, 0x1db7 },
		{ 0x004289EA, 0x1064 },
		{ 0x004458F1, 0x6ab0 },
		{ 0x00468029, 0x20f2 },
		{ 0x0048491E, 0xf3b9 },
		{ 0x004AB99D, 0x7148 },
		{ 0x004C1C9F, 0x84be },
		{ 0x004E2764, 0x41de },
		{ 0x00507ED9, 0x1ada },
		{ 0x005215B4, 0xd47d },
		{ 0x00547C85, 0x6ddd },
		{ 0x0056B74A, 0xe4eb },
		{ 0x005852C4, 0xf4d4 },
		{ 0x005AC949, 0xb551 },
		{ 0x005CD796, 0x83d3 },
		{ 0x005E9A08, 0x85c7 },
		{ 0x0060F0A5, 0x136c },
		{ 0x00629CD1, 0x9856 },
		{ 0x0064D3BB, 0x646b },
		{ 0x0066DF91, 0xa8c0 },
		{ 0x0068E892, 0xfd62 },
		{ 0x006AA1A7, 0xf97a },
		{ 0x006C2D39, 0x8a65 },
		{ 0x006E5928, 0xc9ec },
		{ 0x0070E2F1, 0x1401 },
		{ 0x00720C3A, 0x5c4f },
		{ 0x0074EBF3, 0x6306 },
		{ 0x00763113, 0x6cd9 },
		{ 0x00788C2A, 0xfa0f },
		{ 0x007A9E4B, 0x3d63 },
		{ 0x007C021D, 0x8d08 },
		{ 0x007E5B2C, 0x0df5 },
		{ 0x008016C3, 0x3b6e },
		{ 0x008211C5, 0x20c8 },
		{ 0x0084BED3, 0x4c69 },
		{ 0x00867F09, 0x105e },
		{ 0x00888CA5, 0xd560 },
		{ 0x008A7AA6, 0x41e4 },
		{ 0x008CE2C3, 0xa267 },
		{ 0x008EBA54, 0x7172 },
		{ 0x0090F0D1, 0x3c03 },
		{ 0x0092635E, 0xe4d1 },
		{ 0x0094AE35, 0x4b04 },
		{ 0x00969B70, 0xd447 },
		{ 0x00989794, 0xd20d },
		{ 0x009AC1CD, 0x85fd },
		{ 0x009CA4AA, 0xa50a },
		{ 0x009E265A, 0xb56b },
		{ 0x00A0D6FC, 0x35b5 },
		{ 0x00A24182, 0xa8fa },
		{ 0x00A405F7, 0x42b2 },
		{ 0x00A6C9BE, 0x986c },
		{ 0x00A8E888, 0xdbbb },
		{ 0x00AAA365, 0xc9d6 },
		{ 0x00AC9993, 0xacbc },
		{ 0x00AE3F72, 0xf940 },
		{ 0x00B03288, 0x32d8 },
		{ 0x00B2F67D, 0x6ce3 },
		{ 0x00B440B2, 0x45df },
		{ 0x00B67DA8, 0x5c75 },
		{ 0x00B89694, 0xdcd6 },
		{ 0x00BA29D0, 0x0dcf },
		{ 0x00BCED90, 0xabd1 },
		{ 0x00BE9524, 0x3d59 },
		{ 0x00C0F2B3, 0x26d9 },
		{ 0x00C240C2, 0x30ac },
		{ 0x00C4BF06, 0x51de },
		{ 0x00C68352, 0x003a },
		{ 0x00C868F8, 0xc8d7 },
		{ 0x00CAA9AF, 0x5180 },
		{ 0x00CC25DE, 0xbfd0 },
		{ 0x00CE8F3F, 0x6116 },
		{ 0x00D00D11, 0x21b4 },
		{ 0x00D216C8, 0xf4b5 },
		{ 0x00D4EF51, 0x56b3 },
		{ 0x00D61327, 0xc423 },
		{ 0x00D802EB, 0xcfba },
		{ 0x00DA2BD6, 0x9599 },
		{ 0x00DCFDB5, 0xb8bd },
		{ 0x00DECE09, 0xa50f },
		{ 0x00E037C5, 0x2802 },
		{ 0x00E2ECA7, 0xb89e },
		{ 0x00E40330, 0x5f05 },
		{ 0x00E6ACE5, 0x8808 },
		{ 0x00E8390C, 0xc60c },
		{ 0x00EAB30C, 0xd9b2 },
		{ 0x00ECB932, 0xb10b },
		{ 0x00EEEBB1, 0xe924 },
		{ 0x00F0B8CF, 0x2f6f },
		{ 0x00F23F66, 0x7c87 },
		{ 0x00F440E4, 0x5868 },
		{ 0x00F63401, 0x4c11 },
		{ 0x00F86F6F, 0xc161 },
		{ 0x00FAAD62, 0x1dab },
		{ 0x00FC0C91, 0xb666 },
		{ 0x00FE8189, 0x2d3d },
		{ 0x01000712, 0x76dc },
		{ 0x010208E2, 0x4190 },
		{ 0x01044C60, 0x01db },
		{ 0x0106254D, 0x7106 },
		{ 0x01081649, 0x98d2 },
		{ 0x010AB069, 0x20bc },
		{ 0x010C2BE2, 0xefd5 },
		{ 0x010E1B1E, 0x102a },
		{ 0x0110C888, 0x71b1 },
		{ 0x0112506A, 0x8589 },
		{ 0x0114E064, 0x06b6 },
		{ 0x01161632, 0xb51f },
		{ 0x0118A299, 0x9fbf },
		{ 0x011A94DB, 0xe4a5 },
		{ 0x011C0E71, 0xe8b8 },
		{ 0x011E9EF3, 0xd433 },
		{ 0x012041FA, 0x7807 },
		{ 0x0122D26A, 0xc9a2 },
		{ 0x01246AE1, 0x0f00 },
		{ 0x0126B6A8, 0xf934 },
		{ 0x012836BC, 0x9609 },
		{ 0x012AEDE2, 0xa88e },
		{ 0x012CF8F2, 0xe10e },
		{ 0x012E7530, 0x9818 },
		{ 0x0130CE06, 0x7f6a },
		{ 0x0132490B, 0x0dbb },
		{ 0x0134DCBE, 0x086d },
		{ 0x01363A41, 0x3d2d },
		{ 0x0138835D, 0x9164 },
		{ 0x013A1970, 0x6c97 },
		{ 0x013CCB58, 0xe663 },
		{ 0x013E514E, 0x5c01 },
		{ 0x01401717, 0x6b6b },
		{ 0x01428305, 0x51f4 },
		{ 0x0144A4CC, 0x1c6c },
		{ 0x014675E6, 0x6162 },
		{ 0x0148EBBC, 0x8565 },
		{ 0x014AED25, 0x30d8 },
		{ 0x014C860E, 0xf262 },
		{ 0x014EE316, 0x004e },
		{ 0x01509004, 0x6c06 },
		{ 0x0152C1C0, 0x95ed },
		{ 0x0154F096, 0x1b01 },
		{ 0x0156ED9B, 0xa57b },
		{ 0x01587C24, 0x8208 },
		{ 0x015A5DA7, 0xf4c1 },
		{ 0x015CFF4E, 0xf50f },
		{ 0x015E69E6, 0xc457 },
		{ 0x0160A24B, 0x65b0 },
		{ 0x0162CDF1, 0xd9c6 },
		{ 0x0164AD72, 0x12b7 },
		{ 0x01660309, 0xe950 },
		{ 0x0168E65E, 0x8bbe },
		{ 0x016A31D4, 0xb8ea },
		{ 0x016C3361, 0xfcb9 },
		{ 0x016E8E02, 0x887c },
		{ 0x01703638, 0x62dd },
		{ 0x0172EF1D, 0x1ddf },
		{ 0x0174E345, 0x15da },
		{ 0x0176029F, 0x2d49 },
		{ 0x01782EF0, 0x8cd3 },
		{ 0x017A7D43, 0x7cf3 },
		{ 0x017CA201, 0xfbd4 },
		{ 0x017E0360, 0x4c65 },
		{ 0x0180E8D8, 0x4db2 },
		{ 0x01820C2E, 0x6158 },
		{ 0x0184D83C, 0x3ab5 },
		{ 0x01867A8F, 0x51ce },
		{ 0x0188B382, 0xa3bc },
		{ 0x018AD630, 0x0074 },
		{ 0x018C7A47, 0xd4bb },
		{ 0x018EE93A, 0x30e2 },
		{ 0x019039FF, 0x4adf },
		{ 0x01925D77, 0xa541 },
		{ 0x0194C33D, 0x3dd8 },
		{ 0x019624B0, 0x95d7 },
		{ 0x01984FAA, 0xa4d1 },
		{ 0x019AF889, 0xc46d },
		{ 0x019C6DE5, 0xd3d6 },
		{ 0x019E06D4, 0xf4fb },
		{ 0x01A04BB4, 0x4369 },
		{ 0x01A2827B, 0xe96a },
		{ 0x01A4490A, 0x346e },
		{ 0x01A68ADA, 0xd9fc },
		{ 0x01A8D44B, 0xad67 },
		{ 0x01AAEB4A, 0x8846 },
		{ 0x01AC9BE5, 0xda60 },
		{ 0x01AE44F3, 0xb8d0 },
		{ 0x01B04E07, 0x4404 },
		{ 0x01B27E24, 0x2d73 },
		{ 0x01B47297, 0x3303 },
		{ 0x01B6E409, 0x1de5 },
		{ 0x01B8FFBC, 0xaa0a },
		{ 0x01BA5CD2, 0x4c5f },
		{ 0x01BCDF00, 0xdd0d },
		{ 0x01BEF748, 0x7cc9 },
		{ 0x01C0A6B1, 0x5005 },
		{ 0x01C2030E, 0x713c },
		{ 0x01C46FE5, 0x2702 },
		{ 0x01C65493, 0x41aa },
		{ 0x01C840BC, 0xbe0b },
		{ 0x01CA8B3E, 0x1010 },
		{ 0x01CCD7C4, 0xc90c },
		{ 0x01CE1A9C, 0x2086 },
		{ 0x01D015E6, 0x5768 },
		{ 0x01D272E4, 0xb525 },
		{ 0x01D4B256, 0x206f },
		{ 0x01D6CB39, 0x8583 },
		{ 0x01D867DA, 0xb966 },
		{ 0x01DA73ED, 0xd409 },
		{ 0x01DC6735, 0xce61 },
		{ 0x01DEAA0E, 0xe49f },
		{ 0x01E01B49, 0x5ede },
		{ 0x01E20CFD, 0xf90e },
		{ 0x01E415C3, 0x29d9 },
		{ 0x01E60EA5, 0xc998 },
		{ 0x01E87809, 0xb0d0 },
		{ 0x01EA455D, 0x9822 },
		{ 0x01EC5A0B, 0xc7d7 },
		{ 0x01EEAFDE, 0xa8b4 },
		{ 0x01F0A050, 0x59b3 },
		{ 0x01F2A751, 0x3d17 },
		{ 0x01F4EEF5, 0x2eb4 },
		{ 0x01F643FC, 0x0d81 },
		{ 0x01F8B9A0, 0xb7bd },
		{ 0x01FAA071, 0x5c3b },
		{ 0x01FC0340, 0xc0ba },
		{ 0x01FECF88, 0x6cad },
		{ 0x0200ED43, 0xedb8 },
		{ 0x02028222, 0x8320 },
		{ 0x020412A4, 0x9abf },
		{ 0x0206FC35, 0xb3b6 },
		{ 0x020870E9, 0x03b6 },
		{ 0x020AA719, 0xe20c },
		{ 0x020CBEAE, 0x74b1 },
		{ 0x020E50D4, 0xd29a },
		{ 0x0210BCA5, 0xead5 },
		{ 0x02127B20, 0x4739 },
		{ 0x02149187, 0x9dd2 },
		{ 0x021609C1, 0x77af },
		{ 0x02180B25, 0x04db },
		{ 0x021A24CA, 0x2615 },
		{ 0x021C1E83, 0x73dc },
		{ 0x021EEEF9, 0x1683 },
		{ 0x022042DD, 0xe363 },
		{ 0x02226C65, 0x0b12 },
		{ 0x0224347F, 0x9464 },
		{ 0x02266615, 0x3b84 },
		{ 0x02280966, 0x0d6d },
		{ 0x022A1FEB, 0x6a3e },
		{ 0x022CCA04, 0x7a6a },
		{ 0x022E9490, 0x5aa8 },
		{ 0x0230185F, 0xe40e },
		{ 0x023297E3, 0xcf0b },
		{ 0x02345336, 0x9309 },
		{ 0x02364610, 0xff9d },
		{ 0x0238C709, 0x0a00 },
		{ 0x023A559B, 0xae27 },
		{ 0x023CC2C8, 0x7d07 },
		{ 0x023E23E3, 0x9eb1 },
		{ 0x0240EEA8, 0xf00f },
		{ 0x0242C980, 0x9344 },
		{ 0x02448D9B, 0x8708 },
		{ 0x02464411, 0xa3d2 },
		{ 0x0248A96F, 0x1e01 },
		{ 0x024A6EB8, 0xf268 },
		{ 0x024C025A, 0x6906 },
		{ 0x024E7D2A, 0xc2fe },
		{ 0x0250DCBA, 0xf762 },
		{ 0x02526DCA, 0x575d },
		{ 0x0254063E, 0x8065 },
		{ 0x0256CEDB, 0x67cb },
		{ 0x0258106A, 0x196c },
		{ 0x025A39AC, 0x3671 },
		{ 0x025CB664, 0x6e6b },
		{ 0x025E5CEB, 0x06e7 },
		{ 0x02609C06, 0xfed4 },
		{ 0x0262E82F, 0x1b76 },
		{ 0x0264702B, 0x89d3 },
		{ 0x026638E8, 0x2be0 },
		{ 0x02680576, 0x10da },
		{ 0x026A06A9, 0x7a5a },
		{ 0x026CDF6E, 0x67dd },
		{ 0x026EEF02, 0x4acc },
		{ 0x0270E35B, 0xf9b9 },
		{ 0x02729A9A, 0xdf6f },
		{ 0x0274E451, 0x8ebe },
		{ 0x0276D343, 0xeff9 },
		{ 0x027819F8, 0x17b7 },
		{ 0x027A0956, 0xbe43 },
		{ 0x027C0DB0, 0x60b0 },
		{ 0x027E5D80, 0x8ed5 },
		{ 0x02806C72, 0xd6d6 },
		{ 0x0282A80F, 0xa3e8 },
		{ 0x0284E5EC, 0xa1d1 },
		{ 0x02867DCD, 0x937e },
		{ 0x02882667, 0x38d8 },
		{ 0x028AEBCD, 0xc2c4 },
		{ 0x028C668D, 0x4fdf },
		{ 0x028E5840, 0xf252 },
		{ 0x0290CB93, 0xd1bb },
		{ 0x02921C8F, 0x67f1 },
		{ 0x02944E2B, 0xa6bc },
		{ 0x02961785, 0x5767 },
		{ 0x0298E2C3, 0x3fb5 },
		{ 0x029ABF47, 0x06dd },
		{ 0x029CED9E, 0x48b2 },
		{ 0x029E5173, 0x364b },
		{ 0x02A0004A, 0xd80d },
		{ 0x02A25437, 0x2bda },
		{ 0x02A49B8D, 0xaf0a },
		{ 0x02A664A0, 0x1b4c },
		{ 0x02A8AE40, 0x3603 },
		{ 0x02AAE51F, 0x4af6 },
		{ 0x02AC80FA, 0x4104 },
		{ 0x02AE9687, 0x7a60 },
		{ 0x02B0CD25, 0xdf60 },
		{ 0x02B2BCB3, 0xefc3 },
		{ 0x02B4CD8D, 0xa967 },
		{ 0x02B6FFFC, 0xdf55 },
		{ 0x02B81F78, 0x316e },
		{ 0x02BA0E8B, 0x8eef },
		{ 0x02BC1A89, 0x4669 },
		{ 0x02BEBA0D, 0xbe79 },
		{ 0x02C0587B, 0xcb61 },
		{ 0x02C2901E, 0xb38c },
		{ 0x02C4F808, 0xbc66 },
		{ 0x02C65F98, 0x931a },
		{ 0x02C89C62, 0x256f },
		{ 0x02CA03F9, 0xd2a0 },
		{ 0x02CCA4C0, 0x5268 },
		{ 0x02CEF1DD, 0xe236 },
		{ 0x02D0707E, 0xcc0c },
		{ 0x02D222FE, 0x7795 },
		{ 0x02D4F00E, 0xbb0b },
		{ 0x02D679FC, 0x4703 },
		{ 0x02D89581, 0x2202 },
		{ 0x02DADF2F, 0x16b9 },
		{ 0x02DCFBCE, 0x5505 },
		{ 0x02DE2E69, 0x262f },
		{ 0x02E069E7, 0xc5ba },
		{ 0x02E20F8F, 0x3bbe },
		{ 0x02E42E77, 0xb2bd },
		{ 0x02E6969F, 0x0b28 },
		{ 0x02E82D59, 0x2bb4 },
		{ 0x02EA14FC, 0x5a92 },
		{ 0x02EC879C, 0x5cb3 },
		{ 0x02EEDEB1, 0x6a04 },
		{ 0x02F0A9CB, 0xc2d7 },
		{ 0x02F226F7, 0xffa7 },
		{ 0x02F40DF5, 0xb5d0 },
		{ 0x02F608E7, 0xcf31 },
		{ 0x02F87608, 0x2cd9 },
		{ 0x02FA507C, 0x9e8b },
		{ 0x02FC2A3F, 0x58de },
		{ 0x02FEC003, 0xae1d },
		{ 0x03007959, 0x9b64 },
		{ 0x0302181A, 0xc2b0 },
		{ 0x03045C87, 0xec63 },
		{ 0x0306F6E4, 0xf226 },
		{ 0x0308E603, 0x756a },
		{ 0x030A1562, 0xa39c },
		{ 0x030CF677, 0x026d },
		{ 0x030E56FD, 0x930a },
		{ 0x0310731C, 0x9c09 },
		{ 0x0312CA4E, 0x06a9 },
		{ 0x03148639, 0xeb0e },
		{ 0x0316140E, 0x363f },
		{ 0x0318EB2F, 0x7207 },
		{ 0x031A13D3, 0x6785 },
		{ 0x031C8940, 0x0500 },
		{ 0x031E5AF7, 0x5713 },
		{ 0x0320557E, 0x95bf },
		{ 0x0322982F, 0x4a82 },
		{ 0x0324B60C, 0xe2b8 },
		{ 0x0326A26C, 0x7a14 },
		{ 0x0328D0F4, 0x7bb1 },
		{ 0x032A9258, 0x2bae },
		{ 0x032CEAAE, 0x0cb6 },
		{ 0x032EF0B3, 0x1b38 },
		{ 0x0330E489, 0x92d2 },
		{ 0x03322BC0, 0x8e9b },
		{ 0x0334E8E2, 0xe5d5 },
		{ 0x0336CB76, 0xbe0d },
		{ 0x03380957, 0x7cdc },
		{ 0x033AEEA9, 0xefb7 },
		{ 0x033C0D68, 0x0bdb },
		{ 0x033E26ED, 0xdf21 },
		{ 0x0340E5BA, 0x86d3 },
		{ 0x0342445C, 0xd2d4 },
		{ 0x03444287, 0xf1d4 },
		{ 0x03463A60, 0xe242 },
		{ 0x0348B680, 0x68dd },
		{ 0x034A68AD, 0xb3f8 },
		{ 0x034C283D, 0x1fda },
		{ 0x034EF68D, 0x836e },
		{ 0x03509056, 0x81be },
		{ 0x03524E05, 0x16cd },
		{ 0x0354B3B5, 0xf6b9 },
		{ 0x0356A11D, 0x265b },
		{ 0x0358049C, 0x6fb0 },
		{ 0x035AD934, 0x77e1 },
		{ 0x035C07CD, 0x18b7 },
		{ 0x035E9F07, 0x4777 },
		{ 0x0360959C, 0x8808 },
		{ 0x0362957A, 0x5ae6 },
		{ 0x036400C5, 0xff0f },
		{ 0x0366E520, 0x6a70 },
		{ 0x0368E728, 0x6606 },
		{ 0x036A321D, 0x3bca },
		{ 0x036C0BF2, 0x1101 },
		{ 0x036EC1A9, 0x0b5c },
		{ 0x037034E7, 0x8f65 },
		{ 0x0372D30B, 0x9eff },
		{ 0x0374056C, 0xf862 },
		{ 0x0376AB8C, 0xae69 },
		{ 0x03786234, 0x616b },
		{ 0x037AF5F5, 0xffd3 },
		{ 0x037CDD2B, 0x166c },
		{ 0x037EE8D2, 0xcf45 },
		{ 0x03805144, 0xa00a },
		{ 0x03826A5C, 0xe278 },
		{ 0x03840DE5, 0xd70d },
		{ 0x03869747, 0xd2ee },
		{ 0x03888E63, 0x4e04 },
		{ 0x038A12F2, 0x8354 },
		{ 0x038C597B, 0x3903 },
		{ 0x038EB704, 0xb3c2 },
		{ 0x03902359, 0xa767 },
		{ 0x0392FB74, 0x2661 },
		{ 0x0394521A, 0xd060 },
		{ 0x03962F46, 0x16f7 },
		{ 0x0398F591, 0x4969 },
		{ 0x039A6F1A, 0x474d },
		{ 0x039CA694, 0x3e6e },
		{ 0x039E823F, 0x77db },
		{ 0x03A02FF5, 0xaed1 },
		{ 0x03A253D2, 0x6a4a },
		{ 0x03A4BE72, 0xd9d6 },
		{ 0x03A65896, 0x5adc },
		{ 0x03A8BBAD, 0x40df },
		{ 0x03AA21D8, 0x0b66 },
		{ 0x03AC77E9, 0x37d8 },
		{ 0x03AEF0FB, 0x3bf0 },
		{ 0x03B0DB09, 0xa9bc },
		{ 0x03B211E7, 0xae53 },
		{ 0x03B4DF01, 0xdebb },
		{ 0x03B667F3, 0x9ec5 },
		{ 0x03B827ED, 0x47b2 },
		{ 0x03BA1787, 0xcf7f },
		{ 0x03BCE3A9, 0x30b5 },
		{ 0x03BE34A1, 0xffe9 },
		{ 0x03C02323, 0xbdbd },
		{ 0x03C2370F, 0xf21c },
		{ 0x03C4EBDC, 0xcaba },
		{ 0x03C62A95, 0xc28a },
		{ 0x03C8301E, 0x53b3 },
		{ 0x03CA4EB5, 0x9330 },
		{ 0x03CCE18C, 0x24b4 },
		{ 0x03CE1646, 0xa3a6 },
		{ 0x03D07157, 0xbad0 },
		{ 0x03D2B0B7, 0x3605 },
		{ 0x03D42FFF, 0xcdd7 },
		{ 0x03D6269B, 0x0693 },
		{ 0x03D88BB0, 0x54de },
		{ 0x03DAE167, 0x5729 },
		{ 0x03DCA760, 0x23d9 },
		{ 0x03DECF00, 0x67bf },
		{ 0x03E02963, 0xb366 },
		{ 0x03E28258, 0x7a2e },
		{ 0x03E4FCA3, 0xc461 },
		{ 0x03E6263F, 0x4ab8 },
		{ 0x03E8EB02, 0x5d68 },
		{ 0x03EA0B78, 0x1b02 },
		{ 0x03EC5550, 0x2a6f },
		{ 0x03EEBE0C, 0x2b94 },
		{ 0x03F0806F, 0xb40b },
		{ 0x03F2A949, 0xbe37 },
		{ 0x03F41B2F, 0xc30c },
		{ 0x03F67713, 0x8ea1 },
		{ 0x03F89F8E, 0x5a05 },
		{ 0x03FA5016, 0xdf1b },
		{ 0x03FCDDE6, 0x2d02 },
		{ 0x03FE5B4D, 0xef8d },

		{ 0x02003AC0, 0x00d0 },
		{ 0x0202D4BC, 0x7fb1 },
		{ 0x02042B3E, 0x7f6f },
		{ 0x0206D2C0, 0x7f2c },
		{ 0x0208EB82, 0x7ee9 },
		{ 0x020A0B9A, 0x76c9 },
		{ 0x020C4137, 0x6e88 },
		{ 0x020EFA40, 0x6647 },
		{ 0x02101507, 0x5e07 },
		{ 0x0212020F, 0x55e6 },
		{ 0x0214C3DE, 0x4da5 },
		{ 0x02163152, 0x4164 },
		{ 0x02187A11, 0x3944 },
		{ 0x021A314B, 0x3103 },
		{ 0x021C0C30, 0x28c2 },
		{ 0x021E757D, 0x20a2 },

		{ 0x01C0F05D, 0x0000 },
		{ 0x01C24084, 0x562c },
		{ 0x01C4B60C, 0xb5d2 },
		{ 0x01C6C25D, 0xc98e },
		{ 0x01C874E5, 0xcd87 },
		{ 0x01CAB35C, 0x31a7 },
		{ 0x01CCABF7, 0xc8e7 },
		{ 0x01CE60F5, 0xad4e },
		{ 0x01D06E82, 0x34e8 },
		{ 0x01D20210, 0x190c },
		{ 0x01D44FFD, 0x4461 },
		{ 0x01D6FCCC, 0x9cc3 },
		{ 0x01D8CD46, 0xa842 },
		{ 0x01DAA446, 0x886b },
		{ 0x01DC764D, 0x0000 },
		{ 0x01DE667F, 0x5235 },
		{ 0x0180CF8D, 0x0000 },
		{ 0x01820D53, 0x7fff },
		{ 0x0184E62A, 0x7ffa },
		{ 0x018693FD, 0x7ff5 },
		{ 0x0188D142, 0x7ff0 },
		{ 0x018AF821, 0x7feb },
		{ 0x018CDE00, 0x7fc9 },
		{ 0x018ED3E3, 0x7f87 },
		{ 0x01904654, 0x7f65 },
		{ 0x01921444, 0x7f22 },
		{ 0x0194851C, 0x7ee0 },
		{ 0x019615A2, 0x7a60 },
		{ 0x019815A4, 0x69c0 },
		{ 0x019AF59F, 0x64e0 },
		{ 0x019C7C68, 0x4c00 },
		{ 0x019E3D7A, 0x3c00 },
		{ 0x01A0D5A9, 0x03e0 },
		{ 0x01A22C96, 0x0080 },
		{ 0x01A4F15D, 0x1c0b },
		{ 0x01A6A9DD, 0x45ae },
		{ 0x01A85152, 0x6f7f },
		{ 0x01AA1429, 0x673d },
		{ 0x01AC153D, 0x5ada },
		{ 0x01AED816, 0x5298 },
		{ 0x01B037B8, 0x4635 },
		{ 0x01B2626F, 0x3df3 },
		{ 0x01B4EFE1, 0x3190 },
		{ 0x01B66047, 0x294e },
		{ 0x01B8A17F, 0x1ceb },
		{ 0x01BAE8F8, 0x14a9 },
		{ 0x01BC381B, 0x0846 },
		{ 0x01BEB317, 0x0003 },

		{ 0x07A0D7BD, 0x0000 },
		{ 0x07A2FDF7, 0x7c00 },
		{ 0x07A414B0, 0x0360 },
		{ 0x07A6A375, 0x001f },
		{ 0x07A85770, 0x7fe0 },
		{ 0x07AA2F6E, 0x7fff },
		{ 0x07AC384C, 0x541d },
		{ 0x07AEDFF1, 0x037f },
		{ 0x07B0F8D9, 0x0000 },
		{ 0x07B2EAAF, 0x7fe7 },
		{ 0x07B4750F, 0x7f48 },
		{ 0x07B6346C, 0x7ea9 },
		{ 0x07B8DAC0, 0x7dea },
		{ 0x07BC6350, 0x03e0 },

		{ 0x014064E7, 0x0000 },
		{ 0x014251E1, 0x7ffa },
		{ 0x01443AA9, 0x7f8d },
		{ 0x0146488B, 0x7fff },
		{ 0x014829A2, 0x7ff0 },
		{ 0x014AA74B, 0x7fd9 },
		{ 0x014C2EFA, 0x7ffc },
		{ 0x014E1287, 0x7f4f },
		{ 0x0150E842, 0x7f68 },
		{ 0x0152158D, 0x7ee3 },
		{ 0x0154B670, 0x7e41 },
		{ 0x0156D95E, 0x7e48 },
		{ 0x01584FF1, 0x7da0 },
		{ 0x015A6F2A, 0x7f99 },
		{ 0x015CA37A, 0x76cc },
		{ 0x015ECB80, 0x6f17 },
		{ 0x01602196, 0x6ad3 },
		{ 0x0162D660, 0x5e92 },
		{ 0x0164A29B, 0x624e },
		{ 0x0166DD13, 0x6208 },
		{ 0x01684D54, 0x71a1 },
		{ 0x016A2FF4, 0x6108 },
		{ 0x016CFDFD, 0x64e0 },
		{ 0x016E05A0, 0x4586 },
		{ 0x0170B432, 0x4e2e },
		{ 0x0172E5C7, 0x41ac },
		{ 0x0174CDBB, 0x3107 },
		{ 0x01769E44, 0x3880 },
		{ 0x0178FAD3, 0x3567 },
		{ 0x017A602C, 0x20c3 },
		{ 0x017C096A, 0x0800 },
		{ 0x017E1488, 0x7fff },

		{ 0x0BE0F70E, 0x4cb3 },
		{ 0x0BE2E350, 0x7fff },
		{ 0x0BE4F722, 0x7ffe },
		{ 0x0BE68643, 0x7ffb },
		{ 0x0BE8CB3E, 0x7ff9 },
		{ 0x0BEAABDC, 0x7ff6 },
		{ 0x0BEC000F, 0x7ff4 },
		{ 0x0BEEC3C1, 0x7bd1 },
		{ 0x0BF0C04A, 0x7bcf },
		{ 0x0BF2EB06, 0x77ae },
		{ 0x0BF45561, 0x77ad },
		{ 0x0BF66384, 0x738d },
		{ 0x0BF80566, 0x6f6c },
		{ 0x0BFA6EB1, 0x6f6b },
		{ 0x0BFCF260, 0x6b4a },
		{ 0x0BFE60B7, 0x6b4a },
		{ 0x0C000F4B, 0x6729 },
		{ 0x0C02E81E, 0x6308 },
		{ 0x0C04CF07, 0x6307 },
		{ 0x0C060E25, 0x5ee6 },
		{ 0x0C0839B6, 0x5ac6 },
		{ 0x0C0ABF8D, 0x5ac5 },
		{ 0x0C0C35A0, 0x56a4 },
		{ 0x0C0ECA49, 0x56a0 },
		{ 0x0C10B601, 0x56a0 },
		{ 0x0C12175F, 0x56a0 },
		{ 0x0C14C4BE, 0x5280 },
		{ 0x0C161897, 0x5280 },
		{ 0x0C18651C, 0x4e60 },
		{ 0x0C1AD23F, 0x4e60 },
		{ 0x0C1CB033, 0x4a40 },
		{ 0x0C1EDA23, 0x4a40 },
		{ 0x0C20A71B, 0x4a40 },
		{ 0x0C22DAF3, 0x4620 },
		{ 0x0C24EE1E, 0x4620 },
		{ 0x0C26D154, 0x4201 },
		{ 0x0C280468, 0x4201 },
		{ 0x0C2A34A7, 0x3de1 },
		{ 0x0C2CA338, 0x3de1 },
		{ 0x0C2E71F4, 0x3de1 },
		{ 0x0C30E165, 0x39c1 },
		{ 0x0C32BB85, 0x39c1 },
		{ 0x0C340203, 0x35a1 },
		{ 0x0C363F4A, 0x35a1 },
		{ 0x0C382D53, 0x3181 },
		{ 0x0C3AAA4B, 0x3181 },
		{ 0x0C3C4602, 0x2d61 },
		{ 0x0C3E888C, 0x2d61 },
		{ 0x0C4082BF, 0x2d61 },
		{ 0x0C42D415, 0x2d61 },
		{ 0x0C445792, 0x2941 },
		{ 0x0C46D209, 0x2941 },
		{ 0x0C485FF6, 0x2941 },
		{ 0x0C4AF2EC, 0x2521 },
		{ 0x0C4CDEFD, 0x2521 },
		{ 0x0C4E5AB9, 0x2521 },
		{ 0x0C50B991, 0x2521 },
		{ 0x0C52B6EF, 0x2101 },
		{ 0x0C5435E9, 0x2101 },
		{ 0x0C56A383, 0x1ce1 },
		{ 0x0C58C376, 0x18c1 },
		{ 0x0C5AF004, 0x1080 },
		{ 0x0C5CD659, 0x0c60 },
		{ 0x0C5E7C17, 0x0000 },

		// in-game demo

		{ 0x0740E366, 0x0000 },
		{ 0x07426EEA, 0x03e0 },
		{ 0x07485D97, 0x0000 },
		{ 0x074A20B4, 0x3863 },
		{ 0x074CFCFA, 0x5c21 },
		{ 0x074E37F7, 0x7c00 },
		{ 0x07509EC6, 0x7e2b },
		{ 0x0752736A, 0x14a6 },
		{ 0x07540D3B, 0x318c },
		{ 0x07567A70, 0x4a53 },
		{ 0x075861B3, 0x6739 },
		{ 0x075A48D6, 0x7fff },
		{ 0x075C4AD8, 0x03e0 },
		{ 0x075E7452, 0x294a },

		{ 0x07BA4193, 0x0045 },
		{ 0x07BECBD7, 0x0000 },

		{ 0x03005940, 0x00d0 },
		{ 0x0302E2B3, 0x7f75 },
		{ 0x03047625, 0x7b33 },
		{ 0x030665F4, 0x72b3 },
		{ 0x0308310F, 0x6eaf },
		{ 0x030A0FBE, 0x666d },
		{ 0x030CE5BD, 0x5e2b },
		{ 0x030E624D, 0x5a0a },
		{ 0x03104644, 0x55a9 },
		{ 0x03124604, 0x49a8 },
		{ 0x031420BD, 0x4d67 },
		{ 0x0316579A, 0x3d46 },
		{ 0x03187A4E, 0x3105 },
		{ 0x031AF2C9, 0x24c5 },
		{ 0x031CA091, 0x20a5 },
		{ 0x031E5980, 0x1881 },

		{ 0x0400C0C3, 0x00d0 },
		{ 0x040261D4, 0x7ef5 },
		{ 0x0404D01A, 0x7ad3 },
		{ 0x04065D42, 0x72b1 },
		{ 0x0408E974, 0x6e8f },
		{ 0x040AE9DF, 0x662e },
		{ 0x040CA223, 0x61ec },
		{ 0x040E0187, 0x5dcb },
		{ 0x04102BA8, 0x55a9 },
		{ 0x0412A48D, 0x4d88 },
		{ 0x04142A16, 0x4568 },
		{ 0x041629A5, 0x3d27 },
		{ 0x0418D2E6, 0x3105 },
		{ 0x041A091D, 0x24c6 },
		{ 0x041C0EAF, 0x1ca6 },
		{ 0x041E314B, 0x1881 },

		{ 0x04201D60, 0x0045 },
		{ 0x04229C56, 0x7f75 },
		{ 0x042477E4, 0x7b33 },
		{ 0x04263191, 0x72b3 },
		{ 0x0428AF11, 0x6eae },
		{ 0x042ACCBF, 0x666d },
		{ 0x042C0E5B, 0x5e2b },
		{ 0x042E0363, 0x5e0e },
		{ 0x0430D171, 0x59ed },
		{ 0x04322692, 0x51ac },
		{ 0x0434A314, 0x4d67 },
		{ 0x04366B22, 0x3d46 },
		{ 0x04383EFE, 0x3105 },
		{ 0x043A0272, 0x20a7 },
		{ 0x043C0D9F, 0x1487 },
		{ 0x043E2D92, 0x1881 },

		{ 0x0702BB8D, 0x2c28 },
		{ 0x0704470B, 0x3048 },
		{ 0x07067B2D, 0x3048 },
		{ 0x070840B7, 0x3048 },
		{ 0x070A58B4, 0x3469 },
		{ 0x070C99D1, 0x3469 },
		{ 0x070EDEF2, 0x386a },
		{ 0x071044AF, 0x3c8a },
		{ 0x0712EB75, 0x3c8a },
		{ 0x0714DB75, 0x3449 },
		{ 0x0716C8A4, 0x2c27 },
		{ 0x0718346B, 0x2406 },
		{ 0x071AFE61, 0x2406 },
		{ 0x071C771A, 0x2807 },
		{ 0x071E50A7, 0x2827 },


		// troid screen

		{ 0x07C0B2D7, 0x0019 },
		{ 0x07C222F6, 0x7fff },
		{ 0x07C43550, 0x7b5f },
		{ 0x07C6221A, 0x7fff },
		{ 0x07C8CEF1, 0x6ede },
		{ 0x07CA4B46, 0x7fdd },
		{ 0x07CC3A84, 0x7f7d },
		{ 0x07CEFD3D, 0x5e9a },
		{ 0x07D09D44, 0x7ffa },
		{ 0x07D20DDC, 0x7b5a },
		{ 0x07D46F47, 0x7f79 },
		{ 0x07D6E3E5, 0x72f9 },
		{ 0x07D8666A, 0x7f18 },
		{ 0x07DAF254, 0x4e17 },
		{ 0x07DC2DD1, 0x5e75 },
		{ 0x07DE0A51, 0x7ff5 },
		{ 0x07E0ADE9, 0x62d5 },
		{ 0x07E2206B, 0x7f55 },
		{ 0x07E4C323, 0x7b35 },
		{ 0x07E681E9, 0x7ef4 },
		{ 0x07E8AFE1, 0x5614 },
		{ 0x07EADE06, 0x76d4 },
		{ 0x07EC7D8D, 0x49f4 },
		{ 0x07EE3EA8, 0x7274 },
		{ 0x07F06F90, 0x7f71 },
		{ 0x07F234C6, 0x41b0 },
		{ 0x07F4320A, 0x5a10 },
		{ 0x07F6F668, 0x7ed0 },
		{ 0x07F869F3, 0x7ab0 },
		{ 0x07FA1140, 0x7f50 },
		{ 0x07FCC28A, 0x6a6f },
		{ 0x07FE3235, 0x5e6f },
		{ 0x08003FD7, 0x720f },
		{ 0x0802DE06, 0x418d },
		{ 0x0804C73E, 0x5a0c },
		{ 0x0806F643, 0x6e0c },
		{ 0x0808188C, 0x55ac },
		{ 0x080A636C, 0x7ecb },
		{ 0x080C4160, 0x310b },
		{ 0x080E39BD, 0x7a6b },
		{ 0x0810AD3A, 0x6a6b },
		{ 0x0812C4F2, 0x20ab },
		{ 0x0814DE48, 0x3d2b },
		{ 0x08163D93, 0x632a },
		{ 0x08181879, 0x458a },
		{ 0x081A8813, 0x5689 },
		{ 0x081C9B42, 0x59e9 },
		{ 0x081E708E, 0x5589 },
		{ 0x08202692, 0x6dc8 },
		{ 0x082280AF, 0x1ca8 },
		{ 0x0824397F, 0x5127 },
		{ 0x08267601, 0x3d27 },
		{ 0x0828F05D, 0x4167 },
		{ 0x082A0A0B, 0x3e47 },
		{ 0x082C881E, 0x2ce7 },
		{ 0x082E1ACC, 0x25a5 },
		{ 0x08304151, 0x5105 },
		{ 0x0832C78D, 0x28a5 },
		{ 0x08346959, 0x1c85 },
		{ 0x08362656, 0x6504 },
		{ 0x083856FE, 0x14e4 },
		{ 0x083A4A7E, 0x3ca4 },
		{ 0x083CCC66, 0x1843 },
		{ 0x083E9C6C, 0x0001 },

		// atari screen

		{ 0x0BC0C176, 0x0000 },
		{ 0x0BC2894F, 0x7774 },
		{ 0x0BC45928, 0x66d2 },
		{ 0x0BC6C3C0, 0x5e8d },
		{ 0x0BC8C31C, 0x7bdd },
		{ 0x0BCA6F93, 0x62b9 },
		{ 0x0BCC2CA7, 0x5a92 },
		{ 0x0BCE9F86, 0x522c },
		{ 0x0BD0644B, 0x3dab },
		{ 0x0BD2A1BC, 0x41f2 },
		{ 0x0BD47C0F, 0x41f8 },
		{ 0x0BD6C568, 0x20e6 },
		{ 0x0BD8368A, 0x2951 },
		{ 0x0BDAF5DE, 0x2da4 },
		{ 0x0BDC37CE, 0x1cc9 },
		{ 0x0BDE6895, 0x14a5 },

		{ 0xffffffff, 0xffff }
	};

	data32_t result = protection_base[offset];

	if (offset == 0x300)
		result |= 0x80000000;
	if (offset == 0x3f0)
	{
		UINT32 tag = (last_write_offset << 17) | last_write;
		int i = 0;

		while (lookup_table[i][0] != 0xffffffff)
		{
			if (tag == lookup_table[i][0])
			{
				result = lookup_table[i][1] << 16;
				break;
			}
			i++;
		}

		if (lookup_table[i][0] == 0xffffffff)
		{
			if (last_write_offset*2 >= 0x700 && last_write_offset*2 < 0x720)
				result = rand() << 16;
			else
				result = 0xffff << 16;
			logerror("%06X:Unhandled protection R@%04X = %04X\n", cpu_getpreviouspc(), offset, result);
		}
	}

//	logerror("%06X:Protection R@%04X = %04X\n", cpu_getpreviouspc(), offset, result);
	return result;
}


/*************************************
 *
 *	32-bit stub handlers
 *
 *************************************/

static READ32_HANDLER( inputs_01_r )
{
	return (readinputport(0) << 16) | readinputport(1);
}



/*************************************
 *
 *	Main CPU memory handlers
 *
 *************************************/

static MEMORY_READ32_START( main_readmem )
	{ 0x000000, 0x07ffff, MRA32_ROM },
	{ 0xc80000, 0xc80fff, MRA32_RAM },
	{ 0xca0000, 0xca0fff, atarigx2_protection_r },
	{ 0xd00000, 0xd1ffff, a2d_data_r },
	{ 0xd20000, 0xd20fff, atarigen_eeprom_upper32_r },
	{ 0xd40000, 0xd40fff, MRA32_RAM },
	{ 0xd70000, 0xd7ffff, MRA32_RAM },
	{ 0xe80000, 0xe80003, inputs_01_r },
	{ 0xe82000, 0xe82003, special_port2_r },
	{ 0xe82004, 0xe82007, special_port3_r },
	{ 0xe86000, 0xe86003, atarigen_sound_upper32_r },
	{ 0xff8000, 0xffffff, MRA32_RAM },
MEMORY_END


static MEMORY_WRITE32_START( main_writemem )
	{ 0x000000, 0x07ffff, MWA32_ROM },
	{ 0xc80000, 0xc80fff, MWA32_RAM },
	{ 0xca0000, 0xca0fff, atarigx2_protection_w, &protection_base },
	{ 0xd20000, 0xd20fff, atarigen_eeprom32_w, (data32_t **)&atarigen_eeprom, &atarigen_eeprom_size },
	{ 0xd40000, 0xd40fff, atarigen_666_paletteram32_w, &paletteram32 },
	{ 0xd70000, 0xd71fff, MWA32_RAM },
	{ 0xd72000, 0xd75fff, ataripf_0_split32_w, &ataripf_0_base32 },
	{ 0xd76000, 0xd76fff, atarian_0_vram32_w, &atarian_0_base32 },
	{ 0xd77000, 0xd77fff, MWA32_RAM },
	{ 0xd78000, 0xd78fff, atarirle_0_spriteram32_w, &atarirle_0_spriteram32 },
	{ 0xd79000, 0xd7ffff, MWA32_RAM },
	{ 0xd80000, 0xd9ffff, atarigen_eeprom_enable32_w },
	{ 0xe06000, 0xe06003, atarigen_sound_upper32_w },
	{ 0xe08000, 0xe08003, latch_w },
	{ 0xe0c000, 0xe0c003, atarigen_video_int_ack32_w },
	{ 0xe0e000, 0xe0e003, MWA32_NOP },//watchdog_reset_w },
	{ 0xff8000, 0xffffff, MWA32_RAM },
MEMORY_END




/*************************************
 *
 *	Port definitions
 *
 *************************************/

INPUT_PORTS_START( spclords )
	PORT_START		/* 68.SW (A1=0) */
	PORT_BIT( 0x00ff, IP_ACTIVE_LOW, IPT_UNUSED )
	PORT_BIT( 0x0100, IP_ACTIVE_LOW, IPT_START1 )						/* BLUE button */
	PORT_BIT( 0x0200, IP_ACTIVE_LOW, IPT_BUTTON1 | IPF_PLAYER1 )		/* Left thumb */
	PORT_BIT( 0x0400, IP_ACTIVE_LOW, IPT_BUTTON2 | IPF_PLAYER1 )		/* Left trigger */
	PORT_BIT( 0x0800, IP_ACTIVE_LOW, IPT_BUTTON1 | IPF_PLAYER2 )		/* Throttle forward */
	PORT_BIT( 0x1000, IP_ACTIVE_LOW, IPT_JOYSTICK_RIGHT | IPF_PLAYER1 )
	PORT_BIT( 0x2000, IP_ACTIVE_LOW, IPT_JOYSTICK_LEFT | IPF_PLAYER1 )
	PORT_BIT( 0x4000, IP_ACTIVE_LOW, IPT_BUTTON3 | IPF_PLAYER2 )		/* Throttle button */
	PORT_BIT( 0x8000, IP_ACTIVE_LOW, IPT_JOYSTICK_UP | IPF_PLAYER1 )

	PORT_START		/* 68.SW (A1=1) */
	PORT_BIT( 0x00ff, IP_ACTIVE_LOW, IPT_UNUSED )
	PORT_BIT( 0x0100, IP_ACTIVE_LOW, IPT_START2 )						/* RED button */
	PORT_BIT( 0x0200, IP_ACTIVE_LOW, IPT_BUTTON3 | IPF_PLAYER1 )		/* Right thumb */
	PORT_BIT( 0x0400, IP_ACTIVE_LOW, IPT_BUTTON4 | IPF_PLAYER1 )		/* Right trigger */
	PORT_BIT( 0x0800, IP_ACTIVE_LOW, IPT_BUTTON2 | IPF_PLAYER2 )		/* Throttle reverse */
	PORT_BIT( 0x1000, IP_ACTIVE_LOW, IPT_JOYSTICK_RIGHT | IPF_PLAYER2 )
	PORT_BIT( 0x2000, IP_ACTIVE_LOW, IPT_JOYSTICK_LEFT | IPF_PLAYER2 )
	PORT_BIT( 0x4000, IP_ACTIVE_LOW, IPT_JOYSTICK_DOWN | IPF_PLAYER2 )
	PORT_BIT( 0x8000, IP_ACTIVE_LOW, IPT_JOYSTICK_UP | IPF_PLAYER2 )

	PORT_START      /* 68.STATUS (A2=0) */
	PORT_BIT( 0x0007, IP_ACTIVE_LOW, IPT_UNUSED )	/* +5V */
	PORT_BIT( 0x0008, IP_ACTIVE_HIGH, IPT_UNUSED )	/* A2D.EOC */
	PORT_BIT( 0x0010, IP_ACTIVE_LOW, IPT_UNUSED )	/* /AUDIRQ */
	PORT_BIT( 0x0020, IP_ACTIVE_LOW, IPT_UNUSED )	/* /AUDFULL */
	PORT_SERVICE( 0x0040, IP_ACTIVE_LOW )
	PORT_BIT( 0x0080, IP_ACTIVE_HIGH, IPT_VBLANK )
	PORT_BIT( 0xff00, IP_ACTIVE_LOW, IPT_UNUSED )

	PORT_START      /* 68.STATUS (A2=1) */
	PORT_BIT( 0x0003, IP_ACTIVE_LOW, IPT_UNUSED )	/* +5V */
	PORT_BIT( 0x0004, IP_ACTIVE_LOW, IPT_UNUSED )	/* /XIRQ */
	PORT_BIT( 0x0008, IP_ACTIVE_LOW, IPT_UNUSED )	/* /XFULL */
	PORT_BIT( 0x0010, IP_ACTIVE_LOW, IPT_UNUSED )	/* /SERVICER */
	PORT_BIT( 0x0020, IP_ACTIVE_LOW, IPT_UNUSED )	/* /SER.L */
	PORT_BIT( 0x00c0, IP_ACTIVE_LOW, IPT_UNUSED )	/* +5V */
	PORT_BIT( 0xff00, IP_ACTIVE_LOW, IPT_UNUSED )

	JSA_III_PORT	/* audio board port */

	PORT_START		/* A2D @ 0xD00002 */
	PORT_ANALOG ( 0x00ff, 0x0080, IPT_AD_STICK_X | IPF_PLAYER1, 100, 10, 0x10, 0xf0 )
	PORT_BIT( 0xff00, IP_ACTIVE_LOW, IPT_UNUSED )

	PORT_START		/* A2D @ 0xD00004 */
	PORT_ANALOG ( 0x00ff, 0x0080, IPT_AD_STICK_Y | IPF_PLAYER1, 100, 10, 0x10, 0xf0 )
	PORT_BIT( 0xff00, IP_ACTIVE_LOW, IPT_UNUSED )

	PORT_START		/* A2D @ 0xD00006 */
	PORT_ANALOG ( 0x00ff, 0x0080, IPT_AD_STICK_X | IPF_PLAYER2, 100, 10, 0x10, 0xf0 )
	PORT_BIT( 0xff00, IP_ACTIVE_LOW, IPT_UNUSED )

	PORT_START		/* A2D @ 0xD00008 */
	PORT_ANALOG ( 0x00ff, 0x0080, IPT_AD_STICK_Y | IPF_PLAYER2, 100, 10, 0x10, 0xf0 )
	PORT_BIT( 0xff00, IP_ACTIVE_LOW, IPT_UNUSED )
INPUT_PORTS_END



/*************************************
 *
 *	Graphics definitions
 *
 *************************************/

static struct GfxLayout pflayout =
{
	8,8,
	RGN_FRAC(1,3),
	5,
	{ 0, 0, 1, 2, 3 },
	{ RGN_FRAC(1,3)+0, RGN_FRAC(1,3)+4, 0, 4, RGN_FRAC(1,3)+8, RGN_FRAC(1,3)+12, 8, 12 },
	{ 0*8, 2*8, 4*8, 6*8, 8*8, 10*8, 12*8, 14*8 },
	16*8
};

static struct GfxLayout pftoplayout =
{
	8,8,
	RGN_FRAC(1,3),
	6,
	{ RGN_FRAC(2,3)+0, RGN_FRAC(2,3)+4, 0, 0, 0, 0 },
	{ 3, 2, 1, 0, 11, 10, 9, 8 },
	{ 0*8, 2*8, 4*8, 6*8, 8*8, 10*8, 12*8, 14*8 },
	16*8
};

static struct GfxLayout anlayout =
{
	8,8,
	RGN_FRAC(1,1),
	4,
	{ 0, 1, 2, 3 },
	{ 0, 4, 8, 12, 16, 20, 24, 28 },
	{ 0*8, 4*8, 8*8, 12*8, 16*8, 20*8, 24*8, 28*8 },
	32*8
};

static struct GfxDecodeInfo gfxdecodeinfo[] =
{
	{ REGION_GFX1, 0, &pflayout, 0x000, 64 },
	{ REGION_GFX2, 0, &anlayout, 0x000, 16 },
	{ REGION_GFX1, 0, &pftoplayout, 0x000, 64 },
	{ -1 } /* end of array */
};



/*************************************
 *
 *	Machine driver
 *
 *************************************/

static struct MachineDriver machine_driver_atarigx2 =
{
	/* basic machine hardware */
	{
		{
			CPU_M68EC020,		/* verified */
			ATARI_CLOCK_14MHz,
			main_readmem,main_writemem,0,0,
			atarigen_video_int_gen,1
		},
		JSA_IIIS_CPU
	},
	60, DEFAULT_REAL_60HZ_VBLANK_DURATION,	/* frames per second, vblank duration */
	1,
	init_machine,

	/* video hardware */
	42*8, 30*8, { 0*8, 42*8-1, 0*8, 30*8-1 },
	gfxdecodeinfo,
	2048, 0,
	0,

	VIDEO_TYPE_RASTER | VIDEO_NEEDS_6BITS_PER_GUN | VIDEO_UPDATE_BEFORE_VBLANK,
	0,
	atarig42_vh_start,
	atarig42_vh_stop,
	atarig42_vh_screenrefresh,

	/* sound hardware */
	JSA_IIIS_STEREO(REGION_SOUND1),

	atarigen_nvram_handler
};



/*************************************
 *
 *	Driver initialization
 *
 *************************************/

static void init_spclords(void)
{
	atarigen_eeprom_default = NULL;
	atarijsa_init(1, 4, 2, 0x0040);
	atarijsa3_init_adpcm(REGION_SOUND1);
	atarigen_init_6502_speedup(1, 0x422c, 0x4244);

	atarig42_guardian = 0;
}


static void init_motofren(void)
{
	atarigen_eeprom_default = NULL;
	atarijsa_init(1, 4, 2, 0x0040);
	atarijsa3_init_adpcm(REGION_SOUND1);
	atarigen_init_6502_speedup(1, 0x4168, 0x4180);

	atarig42_guardian = 0;
}


static void init_revrally(void)
{
	atarigen_eeprom_default = NULL;
	atarijsa_init(1, 4, 2, 0x0040);
	atarijsa3_init_adpcm(REGION_SOUND1);
	atarigen_init_6502_speedup(1, 0x416c, 0x4184);

	atarig42_guardian = 0;
}



/*************************************
 *
 *	ROM definition(s)
 *
 *************************************/

ROM_START( spclords )
	ROM_REGION( 0x80000, REGION_CPU1, 0 )	/* 8*64k for 68000 code */
	ROM_LOAD32_BYTE( "136095.21b", 0x00000, 0x20000, 0x2ba99ce2 )
	ROM_LOAD32_BYTE( "136095.22b", 0x00001, 0x20000, 0x631c5009 )
	ROM_LOAD32_BYTE( "136095.23b", 0x00002, 0x20000, 0xbc64ab63 )
	ROM_LOAD32_BYTE( "136095.24b", 0x00003, 0x20000, 0x7284a01a )

	ROM_REGION( 0x14000, REGION_CPU2, 0 )	/* 64k for 6502 code */
	ROM_LOAD( "136095.80a", 0x10000, 0x4000, 0x33bc0ede )
	ROM_CONTINUE(           0x04000, 0xc000 )

	ROM_REGION( 0x60000, REGION_GFX1, ROMREGION_DISPOSE )
	ROM_LOAD( "136095.30a", 0x00000, 0x20000, 0x27e0cfec ) /* playfield, planes 0-1 */
	ROM_LOAD( "136095.31a", 0x20000, 0x20000, 0x5529cdc7 ) /* playfield, planes 2-3 */
	ROM_FILL(               0x40000, 0x20000, 0 )		   /* playfield, planes 4-5 */

	ROM_REGION( 0x020000, REGION_GFX2, ROMREGION_DISPOSE )
	ROM_LOAD( "136095.25a", 0x000000, 0x20000, 0x1669496e ) /* alphanumerics */

	ROM_REGION16_BE( 0x600000, REGION_GFX3, 0 )
	ROM_LOAD16_BYTE( "136095.41b", 0x000000, 0x80000, 0x02ce7e07 )
	ROM_LOAD16_BYTE( "136095.40b", 0x000001, 0x80000, 0xabb80720 )
	ROM_LOAD16_BYTE( "136095.43b", 0x100000, 0x80000, 0x26526345 )
	ROM_LOAD16_BYTE( "136095.42b", 0x100001, 0x80000, 0xc7a163df )
	ROM_LOAD16_BYTE( "136095.45b", 0x200000, 0x80000, 0x53d01714 )
	ROM_LOAD16_BYTE( "136095.44b", 0x200001, 0x80000, 0x60a16e4d )
	ROM_LOAD16_BYTE( "136095.47b", 0x300000, 0x80000, 0x41c873a3 )
	ROM_LOAD16_BYTE( "136095.46b", 0x300001, 0x80000, 0xe885aece )
	ROM_LOAD16_BYTE( "136095.49b", 0x400000, 0x80000, 0x7af90faf )
	ROM_LOAD16_BYTE( "136095.48b", 0x400001, 0x80000, 0x6c553406 )
	ROM_LOAD16_BYTE( "136095.51b", 0x500000, 0x80000, 0x97541074 )
	ROM_LOAD16_BYTE( "136095.50b", 0x500001, 0x80000, 0xa1c11ae8 )

	ROM_REGION( 0x100000, REGION_SOUND1, 0 )	/* 1MB for ADPCM samples */
	ROM_LOAD( "136095.81a",  0x80000, 0x80000, 0x212560dd )
ROM_END


ROM_START( spclorda )
	ROM_REGION( 0x80000, REGION_CPU1, 0 )	/* 8*64k for 68000 code */
	ROM_LOAD32_BYTE( "136095.21a", 0x00000, 0x20000, 0xfe8edb0b )
	ROM_LOAD32_BYTE( "136095.22a", 0x00001, 0x20000, 0xc2d2867b )
	ROM_LOAD32_BYTE( "136095.23a", 0x00002, 0x20000, 0x20a0e443 )
	ROM_LOAD32_BYTE( "136095.24a", 0x00003, 0x20000, 0xd3f0439c )

	ROM_REGION( 0x14000, REGION_CPU2, 0 )	/* 64k for 6502 code */
	ROM_LOAD( "136095.80a", 0x10000, 0x4000, 0x33bc0ede )
	ROM_CONTINUE(           0x04000, 0xc000 )

	ROM_REGION( 0x60000, REGION_GFX1, ROMREGION_DISPOSE )
	ROM_LOAD( "136095.30a", 0x00000, 0x20000, 0x27e0cfec ) /* playfield, planes 0-1 */
	ROM_LOAD( "136095.31a", 0x20000, 0x20000, 0x5529cdc7 ) /* playfield, planes 2-3 */
	ROM_FILL(               0x40000, 0x20000, 0 )		   /* playfield, planes 4-5 */

	ROM_REGION( 0x020000, REGION_GFX2, ROMREGION_DISPOSE )
	ROM_LOAD( "136095.25a", 0x000000, 0x20000, 0x1669496e ) /* alphanumerics */

	ROM_REGION16_BE( 0x600000, REGION_GFX3, 0 )
	ROM_LOAD16_BYTE( "136095.41a", 0x000000, 0x80000, 0x5f9743ee )
	ROM_LOAD16_BYTE( "136095.40a", 0x000001, 0x80000, 0x99b26863 )
	ROM_LOAD16_BYTE( "136095.43a", 0x100000, 0x80000, 0x9c0e09a5 )
	ROM_LOAD16_BYTE( "136095.42a", 0x100001, 0x80000, 0x523bbb39 )
	ROM_LOAD16_BYTE( "136095.45a", 0x200000, 0x80000, 0xac9bf600 )
	ROM_LOAD16_BYTE( "136095.44a", 0x200001, 0x80000, 0x58949b04 )
	ROM_LOAD16_BYTE( "136095.47a", 0x300000, 0x80000, 0x675fee50 )
	ROM_LOAD16_BYTE( "136095.46a", 0x300001, 0x80000, 0xc948c7b6 )
	ROM_LOAD16_BYTE( "136095.49a", 0x400000, 0x80000, 0x04af9a77 )
	ROM_LOAD16_BYTE( "136095.48a", 0x400001, 0x80000, 0x5ad113aa )
	ROM_LOAD16_BYTE( "136095.51a", 0x500000, 0x80000, 0x4635c534 )
	ROM_LOAD16_BYTE( "136095.50a", 0x500001, 0x80000, 0x94bde47d )

	ROM_REGION( 0x100000, REGION_SOUND1, 0 )	/* 1MB for ADPCM samples */
	ROM_LOAD( "136095.81a",  0x80000, 0x80000, 0x212560dd )
ROM_END


ROM_START( motofren )
	ROM_REGION( 0x80000, REGION_CPU1, 0 )	/* 8*64k for 68000 code */
	ROM_LOAD32_BYTE( "94-0221a.23e", 0x00000, 0x20000, 0x134e9ff0 )
	ROM_LOAD32_BYTE( "94-0222a.23j", 0x00001, 0x20000, 0xf6df65c7 )
	ROM_LOAD32_BYTE( "94-0223a.37e", 0x00002, 0x20000, 0xcdb04a4a )
	ROM_LOAD32_BYTE( "94-0224a.37j", 0x00003, 0x20000, 0xf3a9949f )

	ROM_REGION( 0x14000, REGION_CPU2, 0 )	/* 64k for 6502 code */
	ROM_LOAD( "mfs6502.bin", 0x10000, 0x4000, 0x0b1e565c )
	ROM_CONTINUE(            0x04000, 0xc000 )

	ROM_REGION( 0x180000, REGION_GFX1, ROMREGION_DISPOSE )
	ROM_LOAD( "motof2d.bin", 0x000000, 0x80000, 0x1b63b493 ) /* playfield, planes 0-1 */
	ROM_LOAD( "motof5d.bin", 0x080000, 0x80000, 0x6d290056 ) /* playfield, planes 2-3 */
	ROM_LOAD( "motof8d.bin", 0x100000, 0x80000, 0x38197c88 ) /* playfield, planes 4-5 */

	ROM_REGION( 0x020000, REGION_GFX2, ROMREGION_DISPOSE )
	ROM_LOAD( "motof13n.bin", 0x000000, 0x20000, 0x6ab762ad ) /* alphanumerics */

	ROM_REGION16_BE( 0x700000, REGION_GFX3, 0 )
	ROM_LOAD16_BYTE( "motof31n.bin", 0x000000, 0x80000, 0x474770e9 )
	ROM_LOAD16_BYTE( "motof31l.bin", 0x000001, 0x80000, 0xcb777468 )
	ROM_LOAD16_BYTE( "motof33n.bin", 0x100000, 0x80000, 0x353d2dc3 )
	ROM_LOAD16_BYTE( "motof33l.bin", 0x100001, 0x80000, 0x17d49f77 )
	ROM_LOAD16_BYTE( "motof35n.bin", 0x200000, 0x80000, 0x13d89355 )
	ROM_LOAD16_BYTE( "motof35l.bin", 0x200001, 0x80000, 0x924c817e )
	ROM_LOAD16_BYTE( "motof37n.bin", 0x300000, 0x80000, 0x43ee7453 )
	ROM_LOAD16_BYTE( "motof37l.bin", 0x300001, 0x80000, 0x980b9b92 )
	ROM_LOAD16_BYTE( "motof31t.bin", 0x400000, 0x80000, 0x25ac33af )
	ROM_LOAD16_BYTE( "motof31r.bin", 0x400001, 0x80000, 0xd725a27d )
	ROM_LOAD16_BYTE( "motof33t.bin", 0x500000, 0x80000, 0xa0fc90b2 )
	ROM_LOAD16_BYTE( "motof33r.bin", 0x500001, 0x80000, 0xdcc206cf )
	ROM_LOAD16_BYTE( "motof35t.bin", 0x600000, 0x80000, 0x74320763 )
	ROM_LOAD16_BYTE( "motof35r.bin", 0x600001, 0x80000, 0xa7f9df2e )

	ROM_REGION( 0x100000, REGION_SOUND1, 0 )	/* 1MB for ADPCM samples */
	ROM_LOAD( "mfadpcm.bin",  0x80000, 0x80000, 0xfde543c4 )
ROM_END


ROM_START( revrally )
	ROM_REGION( 0x80000, REGION_CPU1, 0 )	/* 8*64k for 68000 code */
	ROM_LOAD32_BYTE( "rrprghh.bin", 0x00000, 0x20000, 0xd2903e9d )
	ROM_LOAD32_BYTE( "rrprghl.bin", 0x00001, 0x20000, 0x1afd500c )
	ROM_LOAD32_BYTE( "rrprglh.bin", 0x00002, 0x20000, 0x2b03a6fc )
	ROM_LOAD32_BYTE( "rrprgll.bin", 0x00003, 0x20000, 0xacf078da )

	ROM_REGION( 0x14000, REGION_CPU2, 0 )	/* 64k for 6502 code */
	ROM_LOAD( "rr65snd.bin", 0x10000, 0x4000, 0xd78429da )
	ROM_CONTINUE(            0x04000, 0xc000 )

	ROM_REGION( 0x180000, REGION_GFX1, ROMREGION_DISPOSE )
	ROM_LOAD( "rralpl.bin", 0x000000, 0x80000, 0x00488dad ) /* playfield, planes 0-1 */
	ROM_LOAD( "rralpm.bin", 0x080000, 0x80000, 0xade27447 ) /* playfield, planes 2-3 */
	ROM_LOAD( "rralph.bin", 0x100000, 0x80000, 0xef04f04e ) /* playfield, planes 4-5 */

	ROM_REGION( 0x020000, REGION_GFX2, ROMREGION_DISPOSE )
	ROM_LOAD( "rralalph.bin", 0x000000, 0x20000, 0x7ca93790 ) /* alphanumerics */

	ROM_REGION16_BE( 0x500000, REGION_GFX3, 0 )
	ROM_LOAD16_BYTE( "rrmo0h.bin", 0x000000, 0x80000, 0x9b7e0315 )
	ROM_LOAD16_BYTE( "rrmo0l.bin", 0x000001, 0x80000, 0x10478697 )
	ROM_LOAD16_BYTE( "rrmo1h.bin", 0x100000, 0x80000, 0xc7a48389 )
	ROM_LOAD16_BYTE( "rrmo1l.bin", 0x100001, 0x80000, 0x085a67c1 )
	ROM_LOAD16_BYTE( "rrmo2h.bin", 0x200000, 0x80000, 0xaea35aff )
	ROM_LOAD16_BYTE( "rrmo2l.bin", 0x200001, 0x80000, 0xb256d6d6 )
	ROM_LOAD16_BYTE( "rrmo3h.bin", 0x300000, 0x80000, 0xe02549d7 )
	ROM_LOAD16_BYTE( "rrmo3l.bin", 0x300001, 0x80000, 0x8c81b537 )
	ROM_LOAD16_BYTE( "rrmo4h.bin", 0x400000, 0x80000, 0x12bf3e11 )
	ROM_LOAD16_BYTE( "rrmo4l.bin", 0x400001, 0x80000, 0xa80175f6 )

	ROM_REGION( 0x100000, REGION_SOUND1, 0 )	/* 1MB for ADPCM samples */
	ROM_LOAD( "rralpc0.bin",  0x80000, 0x80000, 0x1f7b6ecf )
	ROM_LOAD( "rralpc1.bin",  0x80000, 0x80000, 0x7ccd26d7 )
ROM_END




/*************************************
 *
 *	Game driver(s)
 *
 *************************************/

GAMEX( 1992, spclords, 0,        atarigx2, spclords, spclords, ROT0, "Atari Games", "Space Lords", GAME_UNEMULATED_PROTECTION )
GAMEX( 1992, spclorda, spclords, atarigx2, spclords, spclords, ROT0, "Atari Games", "Space Lords (alternate)", GAME_UNEMULATED_PROTECTION )
GAMEX( 1992, motofren, 0,        atarigx2, spclords, motofren, ROT0, "Atari Games", "Moto Frenzy", GAME_UNEMULATED_PROTECTION )
GAMEX( 1993, revrally, 0,        atarigx2, spclords, revrally, ROT0, "Atari Games", "Road Riot Revenge Rally (Prototype)", GAME_UNEMULATED_PROTECTION )
