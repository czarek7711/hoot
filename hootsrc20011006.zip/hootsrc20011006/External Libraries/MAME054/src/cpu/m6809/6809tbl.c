INLINE void abx(void);
INLINE void adca_di(void);
INLINE void adca_ex(void);
INLINE void adca_im(void);
INLINE void adca_ix(void);
INLINE void adcb_di(void);
INLINE void adcb_ex(void);
INLINE void adcb_im(void);
INLINE void adcb_ix(void);
INLINE void adda_di(void);
INLINE void adda_ex(void);
INLINE void adda_im(void);
INLINE void adda_ix(void);
INLINE void addb_di(void);
INLINE void addb_ex(void);
INLINE void addb_im(void);
INLINE void addb_ix(void);
INLINE void addd_di(void);
INLINE void addd_ex(void);
INLINE void addd_im(void);
INLINE void addd_ix(void);
INLINE void anda_di(void);
INLINE void anda_ex(void);
INLINE void anda_im(void);
INLINE void anda_ix(void);
INLINE void andb_di(void);
INLINE void andb_ex(void);
INLINE void andb_im(void);
INLINE void andb_ix(void);
INLINE void andcc(void);
INLINE void asl_di(void);
INLINE void asl_ex(void);
INLINE void asl_ix(void);
INLINE void asla(void);
INLINE void aslb(void);
INLINE void asr_di(void);
INLINE void asr_ex(void);
INLINE void asr_ix(void);
INLINE void asra(void);
INLINE void asrb(void);
INLINE void bcc(void);
INLINE void bcs(void);
INLINE void beq(void);
INLINE void bge(void);
INLINE void bgt(void);
INLINE void bhi(void);
INLINE void bita_di(void);
INLINE void bita_ex(void);
INLINE void bita_im(void);
INLINE void bita_ix(void);
INLINE void bitb_di(void);
INLINE void bitb_ex(void);
INLINE void bitb_im(void);
INLINE void bitb_ix(void);
INLINE void ble(void);
INLINE void bls(void);
INLINE void blt(void);
INLINE void bmi(void);
INLINE void bne(void);
INLINE void bpl(void);
INLINE void bra(void);
INLINE void brn(void);
INLINE void bsr(void);
INLINE void bvc(void);
INLINE void bvs(void);
INLINE void clr_di(void);
INLINE void clr_ex(void);
INLINE void clr_ix(void);
INLINE void clra(void);
INLINE void clrb(void);
INLINE void cmpa_di(void);
INLINE void cmpa_ex(void);
INLINE void cmpa_im(void);
INLINE void cmpa_ix(void);
INLINE void cmpb_di(void);
INLINE void cmpb_ex(void);
INLINE void cmpb_im(void);
INLINE void cmpb_ix(void);
INLINE void cmpd_di(void);
INLINE void cmpd_ex(void);
INLINE void cmpd_im(void);
INLINE void cmpd_ix(void);
INLINE void cmps_di(void);
INLINE void cmps_ex(void);
INLINE void cmps_im(void);
INLINE void cmps_ix(void);
INLINE void cmpu_di(void);
INLINE void cmpu_ex(void);
INLINE void cmpu_im(void);
INLINE void cmpu_ix(void);
INLINE void cmpx_di(void);
INLINE void cmpx_ex(void);
INLINE void cmpx_im(void);
INLINE void cmpx_ix(void);
INLINE void cmpy_di(void);
INLINE void cmpy_ex(void);
INLINE void cmpy_im(void);
INLINE void cmpy_ix(void);
INLINE void com_di(void);
INLINE void com_ex(void);
INLINE void com_ix(void);
INLINE void coma(void);
INLINE void comb(void);
INLINE void cwai(void);
INLINE void daa(void);
INLINE void dec_di(void);
INLINE void dec_ex(void);
INLINE void dec_ix(void);
INLINE void deca(void);
INLINE void decb(void);
INLINE void eora_di(void);
INLINE void eora_ex(void);
INLINE void eora_im(void);
INLINE void eora_ix(void);
INLINE void eorb_di(void);
INLINE void eorb_ex(void);
INLINE void eorb_im(void);
INLINE void eorb_ix(void);
INLINE void exg(void);
INLINE void illegal(void);
INLINE void inc_di(void);
INLINE void inc_ex(void);
INLINE void inc_ix(void);
INLINE void inca(void);
INLINE void incb(void);
INLINE void jmp_di(void);
INLINE void jmp_ex(void);
INLINE void jmp_ix(void);
INLINE void jsr_di(void);
INLINE void jsr_ex(void);
INLINE void jsr_ix(void);
INLINE void lbcc(void);
INLINE void lbcs(void);
INLINE void lbeq(void);
INLINE void lbge(void);
INLINE void lbgt(void);
INLINE void lbhi(void);
INLINE void lble(void);
INLINE void lbls(void);
INLINE void lblt(void);
INLINE void lbmi(void);
INLINE void lbne(void);
INLINE void lbpl(void);
INLINE void lbra(void);
INLINE void lbrn(void);
INLINE void lbsr(void);
INLINE void lbvc(void);
INLINE void lbvs(void);
INLINE void lda_di(void);
INLINE void lda_ex(void);
INLINE void lda_im(void);
INLINE void lda_ix(void);
INLINE void ldb_di(void);
INLINE void ldb_ex(void);
INLINE void ldb_im(void);
INLINE void ldb_ix(void);
INLINE void ldd_di(void);
INLINE void ldd_ex(void);
INLINE void ldd_im(void);
INLINE void ldd_ix(void);
INLINE void lds_di(void);
INLINE void lds_ex(void);
INLINE void lds_im(void);
INLINE void lds_ix(void);
INLINE void ldu_di(void);
INLINE void ldu_ex(void);
INLINE void ldu_im(void);
INLINE void ldu_ix(void);
INLINE void ldx_di(void);
INLINE void ldx_ex(void);
INLINE void ldx_im(void);
INLINE void ldx_ix(void);
INLINE void ldy_di(void);
INLINE void ldy_ex(void);
INLINE void ldy_im(void);
INLINE void ldy_ix(void);
INLINE void leas(void);
INLINE void leau(void);
INLINE void leax(void);
INLINE void leay(void);
INLINE void lsr_di(void);
INLINE void lsr_ex(void);
INLINE void lsr_ix(void);
INLINE void lsra(void);
INLINE void lsrb(void);
INLINE void mul(void);
INLINE void neg_di(void);
INLINE void neg_ex(void);
INLINE void neg_ix(void);
INLINE void nega(void);
INLINE void negb(void);
INLINE void nop(void);
INLINE void ora_di(void);
INLINE void ora_ex(void);
INLINE void ora_im(void);
INLINE void ora_ix(void);
INLINE void orb_di(void);
INLINE void orb_ex(void);
INLINE void orb_im(void);
INLINE void orb_ix(void);
INLINE void orcc(void);
INLINE void pshs(void);
INLINE void pshu(void);
INLINE void puls(void);
INLINE void pulu(void);
INLINE void rol_di(void);
INLINE void rol_ex(void);
INLINE void rol_ix(void);
INLINE void rola(void);
INLINE void rolb(void);
INLINE void ror_di(void);
INLINE void ror_ex(void);
INLINE void ror_ix(void);
INLINE void rora(void);
INLINE void rorb(void);
INLINE void rti(void);
INLINE void rts(void);
INLINE void sbca_di(void);
INLINE void sbca_ex(void);
INLINE void sbca_im(void);
INLINE void sbca_ix(void);
INLINE void sbcb_di(void);
INLINE void sbcb_ex(void);
INLINE void sbcb_im(void);
INLINE void sbcb_ix(void);
INLINE void sex(void);
INLINE void sta_di(void);
INLINE void sta_ex(void);
INLINE void sta_im(void);
INLINE void sta_ix(void);
INLINE void stb_di(void);
INLINE void stb_ex(void);
INLINE void stb_im(void);
INLINE void stb_ix(void);
INLINE void std_di(void);
INLINE void std_ex(void);
INLINE void std_im(void);
INLINE void std_ix(void);
INLINE void sts_di(void);
INLINE void sts_ex(void);
INLINE void sts_im(void);
INLINE void sts_ix(void);
INLINE void stu_di(void);
INLINE void stu_ex(void);
INLINE void stu_im(void);
INLINE void stu_ix(void);
INLINE void stx_di(void);
INLINE void stx_ex(void);
INLINE void stx_im(void);
INLINE void stx_ix(void);
INLINE void sty_di(void);
INLINE void sty_ex(void);
INLINE void sty_im(void);
INLINE void sty_ix(void);
INLINE void suba_di(void);
INLINE void suba_ex(void);
INLINE void suba_im(void);
INLINE void suba_ix(void);
INLINE void subb_di(void);
INLINE void subb_ex(void);
INLINE void subb_im(void);
INLINE void subb_ix(void);
INLINE void subd_di(void);
INLINE void subd_ex(void);
INLINE void subd_im(void);
INLINE void subd_ix(void);
INLINE void swi(void);
INLINE void swi2(void);
INLINE void swi3(void);
INLINE void sync(void);
INLINE void tfr(void);
INLINE void tst_di(void);
INLINE void tst_ex(void);
INLINE void tst_ix(void);
INLINE void tsta(void);
INLINE void tstb(void);

INLINE void pref10(void);
INLINE void pref11(void);

#if (BIG_SWITCH==0)
static void (*m6809_main[0x100])(void) = {
	neg_di, illegal,illegal,com_di, lsr_di, illegal,ror_di, asr_di, 	/* 00 */
	asl_di, rol_di, dec_di, illegal,inc_di, tst_di, jmp_di, clr_di,
	pref10, pref11, nop,	sync,	illegal,illegal,lbra,	lbsr,		/* 10 */
	illegal,daa,	orcc,	illegal,andcc,	sex,	exg,	tfr,
	bra,	brn,	bhi,	bls,	bcc,	bcs,	bne,	beq,		/* 20 */
	bvc,	bvs,	bpl,	bmi,	bge,	blt,	bgt,	ble,
	leax,	leay,	leas,	leau,	pshs,	puls,	pshu,	pulu,		/* 30 */
	illegal,rts,	abx,	rti,	cwai,	mul,	illegal,swi,
	nega,	illegal,illegal,coma,	lsra,	illegal,rora,	asra,		/* 40 */
	asla,	rola,	deca,	illegal,inca,	tsta,	illegal,clra,
	negb,	illegal,illegal,comb,	lsrb,	illegal,rorb,	asrb,		/* 50 */
	aslb,	rolb,	decb,	illegal,incb,	tstb,	illegal,clrb,
	neg_ix, illegal,illegal,com_ix, lsr_ix, illegal,ror_ix, asr_ix, 	/* 60 */
	asl_ix, rol_ix, dec_ix, illegal,inc_ix, tst_ix, jmp_ix, clr_ix,
	neg_ex, illegal,illegal,com_ex, lsr_ex, illegal,ror_ex, asr_ex, 	/* 70 */
	asl_ex, rol_ex, dec_ex, illegal,inc_ex, tst_ex, jmp_ex, clr_ex,
	suba_im,cmpa_im,sbca_im,subd_im,anda_im,bita_im,lda_im, sta_im, 	/* 80 */
	eora_im,adca_im,ora_im, adda_im,cmpx_im,bsr,	ldx_im, stx_im,
	suba_di,cmpa_di,sbca_di,subd_di,anda_di,bita_di,lda_di, sta_di, 	/* 90 */
	eora_di,adca_di,ora_di, adda_di,cmpx_di,jsr_di, ldx_di, stx_di,
	suba_ix,cmpa_ix,sbca_ix,subd_ix,anda_ix,bita_ix,lda_ix, sta_ix, 	/* a0 */
	eora_ix,adca_ix,ora_ix, adda_ix,cmpx_ix,jsr_ix, ldx_ix, stx_ix,
	suba_ex,cmpa_ex,sbca_ex,subd_ex,anda_ex,bita_ex,lda_ex, sta_ex, 	/* b0 */
	eora_ex,adca_ex,ora_ex, adda_ex,cmpx_ex,jsr_ex, ldx_ex, stx_ex,
	subb_im,cmpb_im,sbcb_im,addd_im,andb_im,bitb_im,ldb_im, stb_im, 	/* c0 */
	eorb_im,adcb_im,orb_im, addb_im,ldd_im, std_im, ldu_im, stu_im,
	subb_di,cmpb_di,sbcb_di,addd_di,andb_di,bitb_di,ldb_di, stb_di, 	/* d0 */
	eorb_di,adcb_di,orb_di, addb_di,ldd_di, std_di, ldu_di, stu_di,
	subb_ix,cmpb_ix,sbcb_ix,addd_ix,andb_ix,bitb_ix,ldb_ix, stb_ix, 	/* e0 */
	eorb_ix,adcb_ix,orb_ix, addb_ix,ldd_ix, std_ix, ldu_ix, stu_ix,
	subb_ex,cmpb_ex,sbcb_ex,addd_ex,andb_ex,bitb_ex,ldb_ex, stb_ex, 	/* f0 */
	eorb_ex,adcb_ex,orb_ex, addb_ex,ldd_ex, std_ex, ldu_ex, stu_ex
};
#endif
