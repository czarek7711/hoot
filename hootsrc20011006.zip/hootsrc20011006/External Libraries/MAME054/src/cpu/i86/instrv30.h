static void PREFIXV30(_0fpre)(void);
static void PREFIXV30(_repnc)(void);
static void PREFIXV30(_repc)(void);
static void PREFIXV30(_setalc)(void);
#if 0
static void PREFIXV30(_brks)(void);
#endif
