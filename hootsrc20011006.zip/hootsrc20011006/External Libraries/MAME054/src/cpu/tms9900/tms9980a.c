/*
	generate the tms9980a/tms9981 emulator
*/

#include "tms9900.h"

#define TMS99XX_MODEL TMS9980_ID

#include "99xxcore.h"
