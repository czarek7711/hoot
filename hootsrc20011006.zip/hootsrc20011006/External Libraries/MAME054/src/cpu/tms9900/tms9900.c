/*
	Generate the tms9900 emulator
*/

#include "tms9900.h"

#define TMS99XX_MODEL TMS9900_ID

#include "99xxcore.h"
