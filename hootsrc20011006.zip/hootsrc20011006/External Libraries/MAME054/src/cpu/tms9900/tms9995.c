/*
	generate the tms9995 emulator
*/

#include "tms9900.h"

#define TMS99XX_MODEL TMS9995_ID

#include "99xxcore.h"
