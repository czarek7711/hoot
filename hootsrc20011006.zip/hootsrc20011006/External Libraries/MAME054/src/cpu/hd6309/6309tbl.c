INLINE void illegal( void );
INLINE void neg_di( void );
INLINE void oim_di( void );
INLINE void aim_di( void );
INLINE void com_di( void );
INLINE void lsr_di( void );
INLINE void eim_di( void );
INLINE void ror_di( void );
INLINE void asr_di( void );
INLINE void asl_di( void );
INLINE void rol_di( void );
INLINE void dec_di( void );
INLINE void tim_di( void );
INLINE void inc_di( void );
INLINE void tst_di( void );
INLINE void jmp_di( void );
INLINE void clr_di( void );
INLINE void nop( void );
INLINE void sync( void );
INLINE void sexw( void );
INLINE void lbra( void );
INLINE void lbsr( void );
INLINE void daa( void );
INLINE void daa( void );
INLINE void orcc( void );
INLINE void andcc( void );
INLINE void sex( void );
INLINE void exg( void );
INLINE void tfr( void );
INLINE void bra( void );
INLINE void brn( void );
INLINE void lbrn( void );
INLINE void bhi( void );
INLINE void lbhi( void );
INLINE void bls( void );
INLINE void lbls( void );
INLINE void bcc( void );
INLINE void lbcc( void );
INLINE void bcs( void );
INLINE void lbcs( void );
INLINE void bne( void );
INLINE void lbne( void );
INLINE void beq( void );
INLINE void lbeq( void );
INLINE void bvc( void );
INLINE void lbvc( void );
INLINE void bvs( void );
INLINE void lbvs( void );
INLINE void bpl( void );
INLINE void lbpl( void );
INLINE void bmi( void );
INLINE void lbmi( void );
INLINE void bge( void );
INLINE void lbge( void );
INLINE void blt( void );
INLINE void lblt( void );
INLINE void bgt( void );
INLINE void lbgt( void );
INLINE void ble( void );
INLINE void lble( void );
INLINE void addr_r( void );
INLINE void adcr( void );
INLINE void subr( void );
INLINE void sbcr( void );
INLINE void andr( void );
INLINE void orr( void );
INLINE void eorr( void );
INLINE void cmpr( void );
INLINE void tfmpp( void );
INLINE void tfmmm( void );
INLINE void tfmpc( void );
INLINE void tfmcp( void );
INLINE void bitmd_im( void );
INLINE void leax( void );
INLINE void leay( void );
INLINE void leas( void );
INLINE void leau( void );
INLINE void pshs( void );
INLINE void ldmd_im( void );
INLINE void pshsw( void );
INLINE void pshuw( void );
INLINE void puls( void );
INLINE void pulsw( void );
INLINE void puluw( void );
INLINE void pshu( void );
INLINE void pulu( void );
INLINE void rts( void );
INLINE void abx( void );
INLINE void rti( void );
INLINE void cwai( void );
INLINE void bitd_di( void );
INLINE void bitd_ix( void );
INLINE void bitd_ex( void );
INLINE void mul( void );
INLINE void swi( void );
INLINE void band( void );
INLINE void bitd_im( void );
INLINE void biand( void );
INLINE void bor( void );
INLINE void bior( void );
INLINE void beor( void );
INLINE void bieor( void );
INLINE void ldbt( void );
INLINE void stbt( void );
INLINE void swi2( void );
INLINE void swi3( void );
INLINE void nega( void );
INLINE void coma( void );
INLINE void lsra( void );
INLINE void rora( void );
INLINE void asra( void );
INLINE void asla( void );
INLINE void rola( void );
INLINE void deca( void );
INLINE void inca( void );
INLINE void tsta( void );
INLINE void clra( void );
INLINE void negb( void );
INLINE void negd( void );
INLINE void comb( void );
INLINE void come( void );
INLINE void comf( void );
INLINE void comd( void );
INLINE void comw( void );
INLINE void lsrb( void );
INLINE void lsrd( void );
INLINE void lsrw( void );
INLINE void rorb( void );
INLINE void rord( void );
INLINE void rorw( void );
INLINE void asrb( void );
INLINE void asrd( void );
INLINE void aslb( void );
INLINE void asld( void );
INLINE void rolb( void );
INLINE void rold( void );
INLINE void rolw( void );
INLINE void decb( void );
INLINE void dece( void );
INLINE void decf( void );
INLINE void decd( void );
INLINE void decw( void );
INLINE void incb( void );
INLINE void ince( void );
INLINE void incf( void );
INLINE void incd( void );
INLINE void incw( void );
INLINE void tstb( void );
INLINE void tstd( void );
INLINE void tstw( void );
INLINE void tste( void );
INLINE void tstf( void );
INLINE void clrb( void );
INLINE void clrd( void );
INLINE void clre( void );
INLINE void clrf( void );
INLINE void clrw( void );
INLINE void neg_ix( void );
INLINE void oim_ix( void );
INLINE void aim_ix( void );
INLINE void com_ix( void );
INLINE void lsr_ix( void );
INLINE void eim_ix( void );
INLINE void ror_ix( void );
INLINE void asr_ix( void );
INLINE void asl_ix( void );
INLINE void rol_ix( void );
INLINE void dec_ix( void );
INLINE void tim_ix( void );
INLINE void inc_ix( void );
INLINE void tst_ix( void );
INLINE void jmp_ix( void );
INLINE void clr_ix( void );
INLINE void neg_ex( void );
INLINE void oim_ex( void );
INLINE void aim_ex( void );
INLINE void com_ex( void );
INLINE void lsr_ex( void );
INLINE void eim_ex( void );
INLINE void ror_ex( void );
INLINE void asr_ex( void );
INLINE void asl_ex( void );
INLINE void rol_ex( void );
INLINE void dec_ex( void );
INLINE void tim_ex( void );
INLINE void inc_ex( void );
INLINE void tst_ex( void );
INLINE void jmp_ex( void );
INLINE void clr_ex( void );
INLINE void suba_im( void );
INLINE void cmpa_im( void );
INLINE void sbca_im( void );
INLINE void subd_im( void );
INLINE void subw_im( void );
INLINE void cmpd_im( void );
INLINE void cmpw_im( void );
INLINE void cmpu_im( void );
INLINE void anda_im( void );
INLINE void bita_im( void );
INLINE void lda_im( void );
INLINE void eora_im( void );
INLINE void adca_im( void );
INLINE void ora_im( void );
INLINE void adda_im( void );
INLINE void cmpx_im( void );
INLINE void cmpy_im( void );
INLINE void cmps_im( void );
INLINE void bsr( void );
INLINE void ldx_im( void );
INLINE void ldq_im( void );
INLINE void ldy_im( void );
INLINE void suba_di( void );
INLINE void cmpa_di( void );
INLINE void sbca_di( void );
INLINE void subd_di( void );
INLINE void subw_di( void );
INLINE void cmpd_di( void );
INLINE void cmpw_di( void );
INLINE void cmpu_di( void );
INLINE void anda_di( void );
INLINE void bita_di( void );
INLINE void lda_di( void );
INLINE void ldmd_di( void );
INLINE void sta_di( void );
INLINE void eora_di( void );
INLINE void adca_di( void );
INLINE void ora_di( void );
INLINE void adda_di( void );
INLINE void cmpx_di( void );
INLINE void cmpy_di( void );
INLINE void cmps_di( void );
INLINE void jsr_di( void );
INLINE void ldx_di( void );
INLINE void muld_di( void );
INLINE void divd_im( void );
INLINE void divq_im( void );
INLINE void muld_im( void );
INLINE void divd_di( void );
INLINE void divq_di( void );
INLINE void ldq_di( void );
INLINE void ldy_di( void );
INLINE void stx_di( void );
INLINE void stq_di( void );
INLINE void sty_di( void );
INLINE void suba_ix( void );
INLINE void cmpa_ix( void );
INLINE void sbca_ix( void );
INLINE void subd_ix( void );
INLINE void subw_ix( void );
INLINE void cmpd_ix( void );
INLINE void cmpw_ix( void );
INLINE void cmpu_ix( void );
INLINE void anda_ix( void );
INLINE void bita_ix( void );
INLINE void lda_ix( void );
INLINE void sta_ix( void );
INLINE void eora_ix( void );
INLINE void adca_ix( void );
INLINE void ora_ix( void );
INLINE void adda_ix( void );
INLINE void cmpx_ix( void );
INLINE void cmpy_ix( void );
INLINE void cmps_ix( void );
INLINE void jsr_ix( void );
INLINE void ldx_ix( void );
INLINE void muld_ix( void );
INLINE void divd_ix( void );
INLINE void divq_ix( void );
INLINE void ldq_ix( void );
INLINE void ldy_ix( void );
INLINE void stx_ix( void );
INLINE void stq_ix( void );
INLINE void sty_ix( void );
INLINE void suba_ex( void );
INLINE void cmpa_ex( void );
INLINE void sbca_ex( void );
INLINE void subd_ex( void );
INLINE void subw_ex( void );
INLINE void cmpd_ex( void );
INLINE void cmpw_ex( void );
INLINE void cmpu_ex( void );
INLINE void anda_ex( void );
INLINE void bita_ex( void );
INLINE void lda_ex( void );
INLINE void sta_ex( void );
INLINE void eora_ex( void );
INLINE void adca_ex( void );
INLINE void ora_ex( void );
INLINE void adda_ex( void );
INLINE void cmpx_ex( void );
INLINE void cmpy_ex( void );
INLINE void cmps_ex( void );
INLINE void jsr_ex( void );
INLINE void ldx_ex( void );
INLINE void muld_ex( void );
INLINE void divd_ex( void );
INLINE void divq_ex( void );
INLINE void ldq_ex( void );
INLINE void ldy_ex( void );
INLINE void stx_ex( void );
INLINE void stq_ex( void );
INLINE void sty_ex( void );
INLINE void subb_im( void );
INLINE void sube_im( void );
INLINE void subf_im( void );
INLINE void cmpb_im( void );
INLINE void cmpe_im( void );
INLINE void cmpf_im( void );
INLINE void sbcb_im( void );
INLINE void sbcd_im( void );
INLINE void addd_im( void );
INLINE void addw_im( void );
INLINE void adde_im( void );
INLINE void addf_im( void );
INLINE void andb_im( void );
INLINE void andd_im( void );
INLINE void bitb_im( void );
INLINE void ldb_im( void );
INLINE void lde_im( void );
INLINE void ldf_im( void );
INLINE void eorb_im( void );
INLINE void eord_im( void );
INLINE void adcb_im( void );
INLINE void adcd_im( void );
INLINE void orb_im( void );
INLINE void ord_im( void );
INLINE void addb_im( void );
INLINE void ldd_im( void );
INLINE void ldw_im( void );
INLINE void ldu_im( void );
INLINE void lds_im( void );
INLINE void subb_di( void );
INLINE void sube_di( void );
INLINE void subf_di( void );
INLINE void cmpb_di( void );
INLINE void cmpe_di( void );
INLINE void cmpf_di( void );
INLINE void sbcb_di( void );
INLINE void sbcd_di( void );
INLINE void addd_di( void );
INLINE void addw_di( void );
INLINE void adde_di( void );
INLINE void addf_di( void );
INLINE void andb_di( void );
INLINE void andd_di( void );
INLINE void bitb_di( void );
INLINE void ldb_di( void );
INLINE void lde_di( void );
INLINE void ldf_di( void );
INLINE void stb_di( void );
INLINE void ste_di( void );
INLINE void stf_di( void );
INLINE void eorb_di( void );
INLINE void eord_di( void );
INLINE void adcb_di( void );
INLINE void adcd_di( void );
INLINE void orb_di( void );
INLINE void ord_di( void );
INLINE void addb_di( void );
INLINE void ldd_di( void );
INLINE void ldw_di( void );
INLINE void std_di( void );
INLINE void stw_di( void );
INLINE void ldu_di( void );
INLINE void lds_di( void );
INLINE void stu_di( void );
INLINE void sts_di( void );
INLINE void subb_ix( void );
INLINE void sube_ix( void );
INLINE void subf_ix( void );
INLINE void cmpb_ix( void );
INLINE void cmpe_ix( void );
INLINE void cmpf_ix( void );
INLINE void sbcb_ix( void );
INLINE void sbcd_ix( void );
INLINE void addd_ix( void );
INLINE void addw_ix( void );
INLINE void adde_ix( void );
INLINE void addf_ix( void );
INLINE void andb_ix( void );
INLINE void andd_ix( void );
INLINE void bitb_ix( void );
INLINE void ldb_ix( void );
INLINE void lde_ix( void );
INLINE void ldf_ix( void );
INLINE void stb_ix( void );
INLINE void ste_ix( void );
INLINE void stf_ix( void );
INLINE void eorb_ix( void );
INLINE void eord_ix( void );
INLINE void adcb_ix( void );
INLINE void adcd_ix( void );
INLINE void orb_ix( void );
INLINE void ord_ix( void );
INLINE void addb_ix( void );
INLINE void ldd_ix( void );
INLINE void ldw_ix( void );
INLINE void std_ix( void );
INLINE void stw_ix( void );
INLINE void ldu_ix( void );
INLINE void lds_ix( void );
INLINE void stu_ix( void );
INLINE void sts_ix( void );
INLINE void subb_ex( void );
INLINE void sube_ex( void );
INLINE void subf_ex( void );
INLINE void cmpb_ex( void );
INLINE void cmpe_ex( void );
INLINE void cmpf_ex( void );
INLINE void sbcb_ex( void );
INLINE void sbcd_ex( void );
INLINE void addd_ex( void );
INLINE void addw_ex( void );
INLINE void adde_ex( void );
INLINE void addf_ex( void );
INLINE void andb_ex( void );
INLINE void andd_ex( void );
INLINE void bitb_ex( void );
INLINE void ldb_ex( void );
INLINE void lde_ex( void );
INLINE void ldf_ex( void );
INLINE void stb_ex( void );
INLINE void ste_ex( void );
INLINE void stf_ex( void );
INLINE void eorb_ex( void );
INLINE void eord_ex( void );
INLINE void adcb_ex( void );
INLINE void adcd_ex( void );
INLINE void orb_ex( void );
INLINE void ord_ex( void );
INLINE void addb_ex( void );
INLINE void ldd_ex( void );
INLINE void ldw_ex( void );
INLINE void std_ex( void );
INLINE void stw_ex( void );
INLINE void ldu_ex( void );
INLINE void lds_ex( void );
INLINE void stu_ex( void );
INLINE void sts_ex( void );
INLINE void pref10( void );
INLINE void pref11( void );

static UINT8 flags8i[256]=	 /* increment */
{
CC_Z,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
CC_N|CC_V,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N
};
static UINT8 flags8d[256]= /* decrement */
{
CC_Z,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,CC_V,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,
CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N,CC_N
};

static UINT8 index_cycle_em[256] = {        /* Index Loopup cycle counts, emulated 6809 */
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */

/* 0x0X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x1X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x2X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x3X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x4X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x5X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x6X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x7X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x8X */      2,    3,    2,    3,    0,    1,    1,    1,    1,    4,    1,    4,    1,    5,    4,    0,
/* 0x9X */      3,    6,    5,    6,    3,    4,    4,    4,    4,    7,    4,    7,    4,    8,    7,    5,
/* 0xAX */      2,    3,    2,    3,    0,    1,    1,    1,    1,    4,    1,    4,    1,    5,    4,    5,
/* 0xBX */      5,    6,    5,    6,    3,    4,    4,    4,    4,    7,    4,    7,    4,    8,    7,    8,
/* 0xCX */      2,    3,    2,    3,    0,    1,    1,    1,    1,    4,    1,    4,    1,    5,    4,    3,
/* 0xDX */      4,    6,    5,    6,    3,    4,    4,    4,    4,    7,    4,    7,    4,    8,    7,    8,
/* 0xEX */      2,    3,    2,    3,    0,    1,    1,    1,    1,    4,    1,    4,    1,    5,    4,    3,
/* 0xFX */      4,    6,    5,    6,    3,    4,    4,    4,    4,    7,    4,    7,    4,    8,    7,    8
};

static UINT8 index_cycle_na[256] = {         /* Index Loopup cycle counts, native 6309 */
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */

/* 0x0X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x1X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x2X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x3X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x4X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x5X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x6X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x7X */      1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
/* 0x8X */      1,    2,    1,    3,    0,    1,    1,    1,    1,    3,    1,    2,    1,    3,    1,    0,
/* 0x9X */      3,    5,    4,    5,    3,    4,    4,    4,    4,    5,    4,    7,    4,    6,    5,    5,
/* 0xAX */      1,    2,    1,    2,    0,    1,    1,    1,    1,    3,    1,    2,    1,    3,    1,    2,
/* 0xBX */      5,    5,    4,    5,    3,    4,    4,    4,    4,    7,    4,    5,    4,    6,    4,    7,
/* 0xCX */      1,    2,    1,    2,    0,    1,    1,    1,    1,    3,    1,    2,    1,    3,    1,    1,
/* 0xDX */      4,    5,    4,    5,    3,    4,    4,    4,    4,    7,    4,    5,    4,    6,    4,    7,
/* 0xEX */      1,    2,    1,    2,    0,    1,    1,    1,    1,    3,    1,    2,    1,    3,    1,    1,
/* 0xFX */      4,    5,    4,    5,    3,    4,    4,    4,    4,    7,    4,    5,    4,    6,    4,    7
};

#define IIP0	19			/* Illegal instruction cycle count page 0 */
#define IIP1	20			/* Illegal instruction cycle count page 01 & 11 */

static UINT8 ccounts_page0_em[256] =    /* Cycle Counts Page zero, Emulated 6809 */
{
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */
/* 0x0X */     6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    3,    6,
/* 0x1X */     0,    0,    2,    2,    4, IIP0,    5,    9, IIP0,    2,    3, IIP0,    3,    2,    8,    6,
/* 0x2X */     3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,
/* 0x3X */     4,    4,    4,    4,    5,    5,    6,    5, IIP0,    5,    3,    6,   22,   11, IIP0,   19,
/* 0x4X */     2, IIP0, IIP0,    2,    2, IIP0,    2,    2,    2,    2,    2, IIP0,    2,    2, IIP0,    2,
/* 0x5X */     2, IIP0, IIP0,    2,    2, IIP0,    2,    2,    2,    2,    2, IIP0,    2,    2, IIP0,    2,
/* 0x6X */     6,    7,    7,    6,    6,    7,    6,    6,    6,    6,    6,    7,    6,    6,    3,    6,
/* 0x7X */     7,    7,    7,    7,    7,    7,    7,    7,    7,    7,    7,    7,    7,    7,    4,    7,
/* 0x8X */     2,    2,    2,    4,    2,    2,    2, IIP0,    2,    2,    2,    2,    4,    7,    3, IIP0,
/* 0x9X */     4,    4,    4,    6,    4,    4,    4,    4,    4,    4,    4,    4,    6,    7,    5,    5,
/* 0xAX */     4,    4,    4,    6,    4,    4,    4,    4,    4,    4,    4,    4,    6,    7,    5,    5,
/* 0xBX */     5,    5,    5,    7,    5,    5,    5,    5,    5,    5,    5,    5,    7,    8,    6,    6,
/* 0xCX */     2,    2,    2,    4,    2,    2,    2, IIP0,    2,    2,    2,    2,    3,    5,    3, IIP0,
/* 0xDX */     4,    4,    4,    6,    4,    4,    4,    4,    4,    4,    4,    4,    5,    5,    5,    5,
/* 0xEX */     4,    4,    4,    6,    4,    4,    4,    4,    4,    4,    4,    4,    5,    5,    5,    5,
/* 0xFX */     5,    5,    5,    7,    5,    5,    5,    5,    5,    5,    5,    5,    6,    6,    6,    6
};

static UINT8 ccounts_page0_na[256] =   /* Cycle Counts Page zero, Native 6309 */
{
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */
/* 0x0X */     5,    6,    6,    5,    5,    6,    5,    5,    5,    5,    5,    6,    5,    4,    2,    5,
/* 0x1X */     0,    0,    1,    1,    4, IIP0,    4,    7, IIP0,    1,    2, IIP0,    3,    1,    5,    4,
/* 0x2X */     3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,    3,
/* 0x3X */     4,    4,    4,    4,    4,    4,    4,    4, IIP0,    4,    1,    6,   20,   10, IIP0,   21,
/* 0x4X */     1, IIP0, IIP0,    1,    1, IIP0,    1,    1,    1,    1,    1, IIP0,    1,    1, IIP0,    1,
/* 0x5X */     1, IIP0, IIP0,    1,    1, IIP0,    1,    1,    1,    1,    1, IIP0,    1,    1, IIP0,    1,
/* 0x6X */     6,    7,    7,    6,    6,    7,    6,    6,    6,    6,    6,    7,    6,    5,    3,    6,
/* 0x7X */     6,    7,    7,    6,    6,    7,    6,    6,    6,    6,    6,    7,    6,    5,    3,    6,
/* 0x8X */     2,    2,    2,    3,    2,    2,    2, IIP0,    2,    2,    2,    2,    3,    6,    3, IIP0,
/* 0x9X */     3,    3,    3,    4,    3,    3,    3,    3,    3,    3,    3,    3,    4,    6,    4,    4,
/* 0xAX */     4,    4,    4,    5,    4,    4,    4,    4,    4,    4,    4,    4,    5,    6,    5,    5,
/* 0xBX */     4,    4,    4,    5,    4,    4,    4,    4,    4,    4,    4,    4,    5,    7,    5,    5,
/* 0xCX */     2,    2,    2,    3,    2,    2,    2, IIP0,    2,    2,    2,    2,    3,    5,    3, IIP0,
/* 0xDX */     3,    3,    3,    4,    3,    3,    3,    3,    3,    3,    3,    3,    4,    4,    4,    4,
/* 0xEX */     4,    4,    4,    5,    4,    4,    4,    4,    4,    4,    4,    4,    5,    5,    5,    5,
/* 0xFX */     4,    4,    4,    5,    4,    4,    4,    4,    4,    4,    4,    4,    5,    5,    5,    5
};

static UINT8 ccounts_page01_em[256] =    /* Cycle Counts Page 01, Emulated 6809 */
{
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */
/* 0x0X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x1X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x2X */   IIP1,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,
/* 0x3X */      4,    4,    4,    4,    4,    4,    4,    4,    6,    6,    6,    6, IIP1, IIP1, IIP1,   20,
/* 0x4X */      3,  IIP1,IIP1,    3,    3, IIP1,    3,    3,    3,    3,    3, IIP1,    3,    3, IIP1,    3,
/* 0x5X */   IIP1, IIP1, IIP1,    3,    3, IIP1,    3, IIP1, IIP1,    3,    3, IIP1,    3,    3, IIP1,    3,
/* 0x6X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x7X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x8X */      5,    5,    5,    5,    5,    5,    4, IIP1,    5,    5,    5,    5,    5, IIP1,    5, IIP1,
/* 0x9X */      7,    7,    7,    7,    7,    7,    6,    6,    7,    7,    7,    7,    7, IIP1,    6,    6,
/* 0xAX */      7,    7,    7,    7,    7,    7,    6,    6,    7,    7,    7,    7,    7, IIP1,    6,    6,
/* 0xBX */      8,    8,    8,    8,    8,    8,    7,    7,    8,    8,    8,    8,    8, IIP1,    7,    7,
/* 0xCX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    4, IIP1,
/* 0xDX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    8,    8,    6,    6,
/* 0xEX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    8,    8,    6,    6,
/* 0xFX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    9,    9,    7,    7
};

static UINT8 ccounts_page01_na[256] =   /* Cycle Counts Page 01, Native 6309 */
{
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */
/* 0x0X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x1X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x2X */   IIP1,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,
/* 0x3X */      4,    4,    4,    4,    4,    4,    4,    4,    6,    6,    6,    6, IIP1, IIP1, IIP1,   20,
/* 0x4X */      2, IIP1, IIP1,    2,    2, IIP1,    2,    2,    2,    2,    2, IIP1,    2,    2, IIP1,    2,
/* 0x5X */   IIP1, IIP1, IIP1,    2,    2, IIP1,    2, IIP1, IIP1,    2,    2, IIP1,    2,    2, IIP1,    2,
/* 0x6X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x7X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x8X */      4,    4,    4,    4,    4,    4,    4, IIP1,    4,    4,    4,    4,    4, IIP1,    4, IIP1,
/* 0x9X */      5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5,    5, IIP1,    5,    5,
/* 0xAX */      6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6, IIP1,    6,    6,
/* 0xBX */      6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6,    6, IIP1,    6,    6,
/* 0xCX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    4, IIP1,
/* 0xDX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    7,    7,    5,    5,
/* 0xEX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    8,    8,    6,    6,
/* 0xFX */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    8,    8,    6,    6
};

static UINT8 ccounts_page11_em[256] =    /* Cycle Counts Page 11, Emulated 6809 */
{
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */
/* 0x0X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x1X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x2X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x3X */      7,    7,    7,    7,    7,    7,    7,    8,    3,    3,    3,    3,    4,    5, IIP1,   20,
/* 0x4X */   IIP1, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    3, IIP1,    3,    3, IIP1,    3,
/* 0x5X */   IIP1, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    3, IIP1,    3,    3, IIP1,    3,
/* 0x6X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x7X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x8X */      3,    3, IIP1,    5, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1,    3,    5,   25,   34,   28,
/* 0x9X */      5,    5, IIP1,    7, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5,    7,   27,   36,   30,
/* 0xAX */      5,    5, IIP1,    7, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5,    7,   27,   36,   30,
/* 0xBX */      6,    6, IIP1,    8, IIP1, IIP1,    6,    6, IIP1, IIP1, IIP1,    6,    8,   28,   37,   31,
/* 0xCX */      3,    3, IIP1, IIP1, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1,
/* 0xDX */      5,    5, IIP1, IIP1, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5, IIP1, IIP1, IIP1, IIP1,
/* 0xEX */      5,    5, IIP1, IIP1, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5, IIP1, IIP1, IIP1, IIP1,
/* 0xFX */      6,    6, IIP1, IIP1, IIP1, IIP1,    6,    6, IIP1, IIP1, IIP1,    6, IIP1, IIP1, IIP1, IIP1
};

static UINT8 ccounts_page11_na[256] =    /* Cycle Counts Page 11, Native 6309 */
{
/*	         0xX0, 0xX1, 0xX2, 0xX3, 0xX4, 0xX5, 0xX6, 0xX7, 0xX8, 0xX9, 0xXA, 0xXB, 0xXC, 0xXD, 0xXE, 0xXF */
/* 0x0X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x1X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x2X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x3X */      6,    6,    6,    6,    6,    6,    6,    7,    3,    3,    3,    3,    4,    5, IIP1,   20,
/* 0x4X */   IIP1, IIP1, IIP1,    2, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    2, IIP1,    2,    2, IIP1,    2,
/* 0x5X */   IIP1, IIP1, IIP1,    2, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,    2, IIP1,    2,    2, IIP1,    2,
/* 0x6X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x7X */   IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1, IIP1,
/* 0x8X */      3,    3, IIP1,    4, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1,    3,    4,   25,   34,   28,
/* 0x9X */      4,    4, IIP1,    5, IIP1, IIP1,    4,    4, IIP1, IIP1, IIP1,    4,    5,   26,   35,   29,
/* 0xAX */      5,    5, IIP1,    6, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5,    6,   27,   36,   30,
/* 0xBX */      5,    5, IIP1,    6, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5,    6,   27,   36,   30,
/* 0xCX */      3,    3, IIP1, IIP1, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1,    3, IIP1, IIP1, IIP1, IIP1,
/* 0xDX */      4,    4, IIP1, IIP1, IIP1, IIP1,    4,    4, IIP1, IIP1, IIP1,    4, IIP1, IIP1, IIP1, IIP1,
/* 0xEX */      5,    5, IIP1, IIP1, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5, IIP1, IIP1, IIP1, IIP1,
/* 0xFX */      5,    5, IIP1, IIP1, IIP1, IIP1,    5,    5, IIP1, IIP1, IIP1,    5, IIP1, IIP1, IIP1, IIP1
};

#ifndef BIG_SWITCH

static void (*hd6309_main[0x100])(void) = {
/*	        0xX0,   0xX1,     0xX2,    0xX3,    0xX4,    0xX5,    0xX6,    0xX7,
			0xX8,   0xX9,     0xXA,    0xXB,    0xXC,    0xXD,    0xXE,    0xXF   */

/* 0x0X */  neg_di,  oim_di,  aim_di,  com_di,  lsr_di,  eim_di,  ror_di,  asr_di,
            asl_di,  rol_di,  dec_di,  tim_di,  inc_di,  tst_di,  jmp_di,  clr_di,

/* 0x1X */  pref10,  pref11,  nop,     sync,    sexw,    IIError, lbra,    lbsr,
            IIError, daa,     orcc,    IIError, andcc,   sex,     exg,     tfr,

/* 0x2X */  bra,     brn,     bhi,     bls,     bcc,     bcs,     bne,     beq,
            bvc,     bvs,     bpl,     bmi,     bge,     blt,     bgt,     ble,

/* 0x3X */  leax,    leay,    leas,    leau,    pshs,    puls,    pshu,    pulu,
            IIError, rts,     abx,     rti,     cwai,    mul,     IIError, swi,

/* 0x4X */  nega,    IIError, IIError, coma,    lsra,    IIError, rora,    asra,
            asla,    rola,    deca,    IIError, inca,    tsta,    IIError, clra,

/* 0x5X */  negb,    IIError, IIError, comb,    lsrb,    IIError, rorb,    asrb,
            aslb,    rolb,    decb,    IIError, incb,    tstb,    IIError, clrb,

/* 0x6X */  neg_ix,  oim_ix,  aim_ix,  com_ix,  lsr_ix,  eim_ix,  ror_ix,  asr_ix,
            asl_ix,  rol_ix,  dec_ix,  tim_ix,  inc_ix,  tst_ix,  jmp_ix,  clr_ix,

/* 0x7X */  neg_ex,  oim_ex,  aim_ex,  com_ex,  lsr_ex,  eim_ex,  ror_ex,  asr_ex,
            asl_ex,  rol_ex,  dec_ex,  tim_ex,  inc_ex,  tst_ex,  jmp_ex,  clr_ex,

/* 0x8X */  suba_im, cmpa_im, sbca_im, subd_im, anda_im, bita_im, lda_im,  IIError,
            eora_im, adca_im, ora_im,  adda_im, cmpx_im, bsr,     ldx_im,  IIError,

/* 0x9X */  suba_di, cmpa_di, sbca_di, subd_di, anda_di, bita_di, lda_di,  sta_di,
            eora_di, adca_di, ora_di,  adda_di, cmpx_di, jsr_di,  ldx_di,  stx_di,

/* 0xAX */  suba_ix, cmpa_ix, sbca_ix, subd_ix, anda_ix, bita_ix, lda_ix,  sta_ix,
            eora_ix, adca_ix, ora_ix,  adda_ix, cmpx_ix, jsr_ix,  ldx_ix,  stx_ix,

/* 0xBX */  suba_ex, cmpa_ex, sbca_ex, subd_ex, anda_ex, bita_ex, lda_ex,  sta_ex,
            eora_ex, adca_ex, ora_ex,  adda_ex, cmpx_ex, jsr_ex,  ldx_ex,  stx_ex,

/* 0xCX */  subb_im, cmpb_im, sbcb_im, addd_im, andb_im, bitb_im, ldb_im,  IIError,
            eorb_im, adcb_im, orb_im,  addb_im, ldd_im,  ldq_im,  ldu_im,  IIError,

/* 0xDX */  subb_di, cmpb_di, sbcb_di, addd_di, andb_di, bitb_di, ldb_di,  stb_di,
            eorb_di, adcb_di, orb_di,  addb_di, ldd_di,  std_di,  ldu_di,  stu_di,

/* 0xEX */  subb_ix, cmpb_ix, sbcb_ix, addd_ix, andb_ix, bitb_ix, ldb_ix,  stb_ix,
            eorb_ix, adcb_ix, orb_ix,  addb_ix, ldd_ix,  std_ix,  ldu_ix,  stu_ix,

/* 0xFX */  subb_ex, cmpb_ex, sbcb_ex, addd_ex, andb_ex, bitb_ex, ldb_ex,  stb_ex,
            eorb_ex, adcb_ex, orb_ex,  addb_ex, ldd_ex,  std_ex,  ldu_ex,  stu_ex
};

static void (*hd6309_page01[0x100])(void) = {
/*	        0xX0,   0xX1,     0xX2,    0xX3,    0xX4,    0xX5,    0xX6,    0xX7,
			0xX8,   0xX9,     0xXA,    0xXB,    0xXC,    0xXD,    0xXE,    0xXF   */

/* 0x0X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x1X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x2X */  IIError, lbrn,    lbhi,    lbls,    lbcc,    lbcs,    lbne,    lbeq,
			lbvc,    lbvs,    lbpl,    lbmi,    lbge,    lblt,    lbgt,    lble,

/* 0x3X */  addr_r,  adcr,    subr,    sbcr,    andr,    orr,     eorr,    cmpr,
			pshsw,   pulsw,   pshuw,   puluw,   IIError, IIError, IIError, swi2,

/* 0x4X */  negd,    IIError, IIError, comd,    lsrd,    IIError, rord,    asrd,
			asld,    rold,    decd,    IIError, incd,    tstd,    IIError, clrd,

/* 0x5X */  IIError, IIError, IIError, comw,    lsrw,    IIError, rorw,    IIError,
			IIError, rolw,    decw,    IIError, incw,    tstw,    IIError, clrw,

/* 0x6X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x7X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x8X */  subw_im, cmpw_im, sbcd_im, cmpd_im, andd_im, bitd_im, ldw_im,  IIError,
			eord_im, adcd_im, ord_im,  addw_im, cmpy_im, IIError, ldy_im,  IIError,

/* 0x9X */  subw_di, cmpw_di, sbcd_di, cmpd_di, andd_di, bitd_di, ldw_di,  stw_di,
			eord_di, adcd_di, ord_di,  addw_di, cmpy_di, IIError, ldy_di,  sty_di,

/* 0xAX */  subw_ix, cmpw_ix, sbcd_ix, cmpd_ix, andd_ix, bitd_ix, ldw_ix,  stw_ix,
			eord_ix, adcd_ix, ord_ix,  addw_ix, cmpy_ix, IIError, ldy_ix,  sty_ix,

/* 0xBX */  subw_ex, cmpw_ex, sbcd_ex, cmpd_ex, andd_ex, bitd_ex, ldw_ex,  stw_ex,
			eord_ex, adcd_ex, ord_ex,  addw_ex, cmpy_ex, IIError, ldy_ex,  sty_ex,

/* 0xCX */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, lds_im,  IIError,

/* 0xDX */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, ldq_di,  stq_di,  lds_di,  sts_di,

/* 0xEX */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, ldq_ix,  stq_ix,  lds_ix,  sts_ix,

/* 0xFX */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, ldq_ex,  stq_ex,  lds_ex,  sts_ex
};
static void (*hd6309_page11[0x100])(void) = {
/*	        0xX0,   0xX1,     0xX2,    0xX3,    0xX4,    0xX5,    0xX6,    0xX7,
			0xX8,   0xX9,     0xXA,    0xXB,    0xXC,    0xXD,    0xXE,    0xXF   */

/* 0x0X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x1X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x2X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x3X */  band,    biand,   bor,     bior,    beor,    bieor,   ldbt,    stbt,
			tfmpp,   tfmmm,   tfmpc,   tfmcp,   bitmd_im,ldmd_im, IIError, swi3,

/* 0x4X */  IIError, IIError, IIError, come,    IIError, IIError, IIError, IIError,
			IIError, IIError, dece,    IIError, ince,    tste,    IIError, clre,

/* 0x5X */  IIError, IIError, IIError, comf,    IIError, IIError, IIError, IIError,
			IIError, IIError, decf,    IIError, incf,    tstf,    IIError, clrf,

/* 0x6X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x7X */  IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,
			IIError, IIError, IIError, IIError, IIError, IIError, IIError, IIError,

/* 0x8X */  sube_im, cmpe_im, IIError, cmpu_im, IIError, IIError, lde_im,  IIError,
			IIError, IIError, IIError, adde_im, cmps_im, divd_im, divq_im, muld_im,

/* 0x9X */  sube_di, cmpe_di, IIError, cmpu_di, IIError, IIError, lde_di,  ste_di,
			IIError, IIError, IIError, adde_di, cmps_di, divd_di, divq_di, muld_di,

/* 0xAX */  sube_ix, cmpe_ix, IIError, cmpu_ix, IIError, IIError, lde_ix,  ste_ix,
			IIError, IIError, IIError, adde_ix, cmps_ix, divd_ix, divq_ix, muld_ix,

/* 0xBX */  sube_ex, cmpe_ex, IIError, cmpu_ex, IIError, IIError, lde_ex,  ste_ex,
			IIError, IIError, IIError, adde_ex, cmps_ex, divd_ex, divq_ex, muld_ex,

/* 0xCX */  subf_im, cmpf_im, IIError, IIError, IIError, IIError, ldf_im,  IIError,
			IIError, IIError, IIError, addf_im, IIError, IIError, IIError, IIError,

/* 0xDX */  subf_di, cmpf_di, IIError, IIError, IIError, IIError, ldf_di,  stf_di,
			IIError, IIError, IIError, addf_di, IIError, IIError, IIError, IIError,

/* 0xEX */  subf_ix, cmpf_ix, IIError, IIError, IIError, IIError, ldf_ix,  stf_ix,
			IIError, IIError, IIError, addf_ix, IIError, IIError, IIError, IIError,

/* 0xFX */  subf_ex, cmpf_ex, IIError, IIError, IIError, IIError, ldf_ex,  stf_ex,
			IIError, IIError, IIError, addf_ex, IIError, IIError, IIError, IIError

};

#endif /* BIG_SWITCH */
